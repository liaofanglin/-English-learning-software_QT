#include "unfamilyword.h"
#include "ui_unfamilyword.h"
#include<QToolButton>
#include<QDebug>
#include"fillout.h"
#include"errow.h"
UnfamilyWord::UnfamilyWord(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::UnfamilyWord)
{
    ui->setupUi(this);
     this->setWindowFlags(Qt::FramelessWindowHint);//去掉边框
    //接受数据库传来的容器
    m_word=wordservice.getMyselfWords(m_user->id);
    //返回上一个界面
    connect(ui->btnBack,&QToolButton::clicked,[=](){

        Function *function=new Function(nullptr);

        function->move(this->x(),this->y());

        function->show();

        this->close();
    });
    ui->stackedWidget->setCurrentIndex(0);
    connect(ui->btnnext,&QPushButton::clicked,[=]()mutable{
        ++j;
        ui->stackedWidget->setCurrentIndex(j);
    });
    connect(ui->btnMin,&QToolButton::clicked,this,&QWidget::showMinimized);
    connect(ui->btnClose,&QPushButton::clicked,this,[=](){
        this->close();
    });
    connect(ui->btnbefore,&QPushButton::clicked,[=]()mutable{
        --j;
        if(j<0)
        {
            Errow *error= new Errow(this,"页数错误！");

            error->show();

            return ;
        }
        ui->stackedWidget->setCurrentIndex(j);
    });
    int m=0;
    int n=0;
   for(QVector<Word>::iterator it=m_word.begin();it!=m_word.end();it++)
    {
       if(m<14)
       {
            mybtn *btn=new mybtn(ui->page_1,it->word);

            btn->show();

            btn->move(0,n*50);

            connect(btn,&QPushButton::clicked,[=](){
            FillOut *fillout=new FillOut(nullptr,0,*it);

            fillout->move(this->x(),this->y());

            this->close();

            fillout->show();
            });

            n++;

            if(n==14)
            {
              n=0;
            }
       }
       else if (m>=14&&m<28)
       {
           mybtn *btn=new mybtn(ui->page_2,it->word);

           btn->show();

           btn->move(0,n*50);

           connect(btn,&QPushButton::clicked,[=](){

           FillOut *fillout=new FillOut(nullptr,0,*it);

           fillout->move(this->x(),this->y());

           this->close();
           fillout->show();
           });
           n++;
           if(n==14)
           {
             n=0;
           }
       }
       else if (m>=28&&m<42)
       {

           mybtn *btn=new mybtn(ui->page_3,it->word);
           btn->show();
           btn->move(0,n*50);
           connect(btn,&QPushButton::clicked,[=](){

           FillOut *fillout=new FillOut(nullptr,0,*it);

           fillout->move(this->x(),this->y());

           this->close();

           fillout->show();
           });
           n++;
           if(n==14)
           {
             n=0;
           }
       }
       else if (m>=42&&m<56)
       {
           mybtn *btn=new mybtn(ui->page_4,it->word);
           btn->show();
           btn->move(0,n*50);
           connect(btn,&QPushButton::clicked,[=](){
           FillOut *fillout=new FillOut(nullptr,0,*it);

            fillout->move(this->x(),this->y());

           this->close();

           fillout->show();

           });
           n++;
           if(n==14)
           {
             n=0;
           }
       }
        m++;
    }


}
UnfamilyWord::~UnfamilyWord()
{
    delete ui;
}
void UnfamilyWord::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = true;

        //获得鼠标的初始位置

        mouseStartPoint = event->globalPos();

        //mouseStartPoint = event->pos();
        //获得窗口的初始位置

        windowTopLeftPoint = this->frameGeometry().topLeft();
    }
}
void UnfamilyWord::mouseMoveEvent(QMouseEvent *event)
{
    if(m_bDrag)
    {
        //获得鼠标移动的距离
        QPoint distance = event->globalPos() - mouseStartPoint;

        //QPoint distance = event->pos() - mouseStartPoint;
        //改变窗口的位置

        this->move(windowTopLeftPoint + distance);
    }
}
void UnfamilyWord::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = false;
    }
}


