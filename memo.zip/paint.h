#ifndef PAINT_H
#define PAINT_H

#include <QTextStream>
#include <QFileDialog>
#include <QMessageBox>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QWidget>
#include <QBrush>
#include <QStack>
#include <QFile>
#include <QPen>
#include <QFileDialog>//文本对话框
#include <QTextEdit>//文本编辑器
#include <QVector>

#include "ellipse.h"
#include "polygon.h"
#include "shape.h"
#include "type.h"
#include "line.h"
#include "rect.h"
#include "pen.h"

class Paint : public QWidget
{
    Q_OBJECT
public:
    explicit Paint(QWidget *parent = 0);
protected:
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mousePressEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
public slots:
    void set_shape(type);
    void set_color(QColor);
    void set_brush(QColor);
    void set_width(int);
    void set_alpha(int);
    void set_straight(bool);
    void open_file();
    void save_file();
    void saveAs_file();
    void Undo();
    void Redo();
    void Reset();
private:
    type shapeType;
    QStack<Shape *>stack;
    QStack<Shape *>redoStack;  //撤销恢复用
    Shape *shape;
    QColor currentColor;
    QColor currentBrush;
    QString currentPath;
    int currentWidth;

    bool stop_polygon;
    bool is_straight;

};

#endif // PAINT_H
