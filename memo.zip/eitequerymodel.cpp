#include "eitequerymodel.h"
#include<QSqlQuery>
#include<QDebug>
#include<QColor>
#include<QTableWidgetItem>
#include <QModelIndex>

eiteQuerymodel::eiteQuerymodel()
{

}

bool eiteQuerymodel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    Q_UNUSED(role);
    qDebug()<<"000";
    //[1]判断是否为有效列 学习打---id 用户名 年龄 地址 薪资
    if(index.column()<1 || index.column() > 4)
    return false;

    //获取列所对应的id
    QModelIndex prinmaryIndex =QSqlQueryModel::index(index.row(),0);
    int id=this->data(prinmaryIndex).toInt();//获取到表中字段的id

    //在修改行时，将数据清除，把整个model清空
    this->clear();
    bool ok1,ok2,ok3,ok4;
    //根据需求，来修改所对应的列
    if(index.column() == 1)
    {
        ok1 = setName(id,value.toString());
        refresh();

        return ok1;
    }

    if(index.column() == 2)
    {
        ok2 = setAge(id,value.toInt());
        refresh();

        return ok2;
    }
    if(index.column() == 3)
    {
        ok3 = setaddress(id,value.toString());
        refresh();

        return ok3;
    }
    if(index.column() == 4)
    {
        ok4= setsalary(id,value.toInt());
        refresh();

        return ok4;
    }
    //刷新数据
    qDebug()<<"okk";
    //refresh();

    //return ok;
}

Qt::ItemFlags eiteQuerymodel::flags(const QModelIndex &index) const
{
    qDebug()<<"ok";
    //[1]获取当前单元格的编辑状态
    Qt::ItemFlags flags=QSqlQueryModel::flags(index);
    qDebug()<<"ok";
    //[2]给现有标志增加一个可以编辑的标志
    //if(index.column() == 1)
    //qDebug()<<flags;
    //return flags;
    //else
    //{
    flags = flags | Qt::ItemIsEditable;//给他设置一个可编辑的状态
    //qDebug()<<flags;
    //QTableWidgetItem* pItem = ui.tablewidget->item(iRowIndex, iColIndex);
    //pItem->setFlags(pItem->flags() &amp; (~Qt::ItemIsEditable));


    return flags;
    //}

}

QVariant eiteQuerymodel::data(const QModelIndex &index, int role) const
{
    QVariant value =QSqlQueryModel::data(index,role);
    if(role==Qt::TextColorRole && index.column()==0)
       return QVariant::fromValue(QColor(Qt::gray));
         return value;

}

void eiteQuerymodel::refresh()
{
    //相当于将数据库的数据(查询)出来，转换成一个model
    this->setQuery("select * from staff");
    this->setHeaderData(0,Qt::Horizontal,"Id");
    this->setHeaderData(1,Qt::Horizontal,"日期");
    this->setHeaderData(2,Qt::Horizontal,"所用时长");
    this->setHeaderData(3,Qt::Horizontal,"单词个数");
    this->setHeaderData(4,Qt::Horizontal,"连续打卡天数");
    qDebug()<<"ool";

}

bool eiteQuerymodel::setName(int useId, const QString &name)
{
    //相当于一个(刷新)的操作
    QSqlQuery query;
    query.prepare("update staff set name= ? where id= ?");
    query.addBindValue(name);
    query.addBindValue(useId);
    return query.exec();
    qDebug()<<"999";

}

bool eiteQuerymodel::setAge(int useId, const int &age)
{
    //相当于一个(刷新)的操作
    QSqlQuery query;
    query.prepare("update staff set age= ? where id= ?");
    query.addBindValue(age);
    query.addBindValue(useId);
    return query.exec();
    qDebug()<<"888";

}
bool eiteQuerymodel::setaddress(int useId, const QString &address)
{
    //相当于一个(刷新)的操作
    QSqlQuery query;
    query.prepare("update staff set address= ? where id= ?");
    query.addBindValue(address);
    query.addBindValue(useId);
    return query.exec();
    qDebug()<<"777";

}
bool eiteQuerymodel::setsalary(int useId, const int &salary)
{
    //相当于一个(刷新)的操作
    QSqlQuery query;
    query.prepare("update staff set salary= ? where id= ?");
    query.addBindValue(salary);
    query.addBindValue(useId);
    return query.exec();
    qDebug()<<"666";

}
