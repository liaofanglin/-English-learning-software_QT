#include "mainwindow.h"
#include "login.h"
#include "mynote.h"
#include "signup.h"

#include <QApplication>
#include <QTranslator>//翻译类,用于解决字体对话框和颜色对话框里的英文
#include <QLatin1Literal>//对US-ASCII/Latin-1编码的字符串进行了简单封装
#include <QLibraryInfo>//读取 qt.conf 文件,获取Qt库的信息


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //MainWindow w;
    //w.show();
//    login lg;
//    lg.show();
    SignUp sign;
    sign.show();
    //将对话框翻译成中文,用于解决字体对话框和颜色对话框里出现的英文
    //1.获取翻译文件的名字
    QString translatorFileName = QLatin1String("qt_");//加载本地翻译文件的格式
    //QLocale类属于翻译类的一部分,解决不同区域显示格式的问题
    translatorFileName += QLocale::system().name();//获取翻译文件的名字
    //2.加载翻译文件
    QTranslator *translator = new QTranslator(&a);//初始化翻译类对象指针
    //load()------>加载,参数一:翻译文件的名字,参数二:翻译文件所在的Qt库位置,返回的数据放置到指定的元素中
    if (translator->load(translatorFileName, QLibraryInfo::location(QLibraryInfo::TranslationsPath)))
    {
        a.installTranslator(translator);//3.安装翻译文件,进行Qt语言翻译
    }

    return a.exec();
}
