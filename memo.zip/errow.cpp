#include "errow.h"
#include "ui_errow.h"

Errow::Errow(QWidget *parent,QString m_error) :
    QWidget(parent),
    ui(new Ui::Errow)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉边框
    ui->btnError->setAutoRaise(true);
    ui->btnError->setStyleSheet("font-size:22px;color:white;font-family:PingFang SC;background-color: #FF1A8C;border-radius:25px;");
    ui->btnError->setText(m_error);
    ui->btnError->setParent(this);
    this->move(65,0);
    QPropertyAnimation *pAnimation = new QPropertyAnimation(ui->btnError, "pos");
    pAnimation->setDuration(500);
    pAnimation->setLoopCount(1);
    pAnimation->setKeyValueAt(0,   QPoint(0, -50));
    pAnimation->setKeyValueAt(0.1, QPoint(0, -40 ));
    pAnimation->setKeyValueAt(0.2, QPoint(0, -30 ));
    pAnimation->setKeyValueAt(0.3, QPoint(0, -20 ));
    pAnimation->setKeyValueAt(1.0, QPoint(0, 0 ));
    pAnimation->start(QAbstractAnimation::DeleteWhenStopped);
    QTimer::singleShot(3000, [=](){
        delete ui->btnError;
        delete this;
    });  // SLOT槽填入一个槽函数
}

Errow::~Errow()
{
    delete ui;
}
