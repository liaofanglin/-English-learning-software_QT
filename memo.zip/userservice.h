#ifndef USERSERVICE_H
#define USERSERVICE_H
#include <QSqlDatabase>
#include <QVariant>
#include"user.h"

class UserService
{
public:
    UserService();
    /**
      * @brief login 登录
      * @param objUser 用户对象引用，登录成功会写入id 账户 id
      * @return 成功:true，失败:false
      */
      bool login(User *objUser);
      /**
       * @brief isEmailExist 账号是否已经被注册
       * @param account 注册账号
       * @return 存在：true；不存在：false
       */
      bool isAccountExist(QString account);
      /**
       * @brief registerUser 注册用户
       * @param objUser 用户对象
       * @return 成功:true，失败:false
       */
      bool registerUser(User *objUser);
      /**
       * @brief verifyAccoutAndBirthday
       * @param account 账户
       * @param birthday 出生日期
       * @return 验证通过:true，验证失败:false
       */
      bool verifyAccoutAndBirthday(QString account, QString birthday);
      /**
       * @brief modifyPassword
       * @param objUser 用户对象
       * @return
       */
      bool modifyPassword(User *objUser); // 修改密码
private:
      void connectAndOpenDb();
      QString AddPassword();
private:
    QSqlDatabase db;
    QString m_dbName;
    QString m_host;
    QString m_user;
    QString m_pwd;
    int m_port;
};

#endif // USERSERVICE_H

