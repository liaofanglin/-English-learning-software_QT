#ifndef WORDSERVICE_H
#define WORDSERVICE_H
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <QVector>
#include"word.h"

class WordService
{
public:
    WordService();
    /**
         * @brief getRandomWord 获取随机单词
         * @param wordId 当前单词的id号，避免随机出现重复，第一次查询参数：-1
         * @return 单词对象
         */
        Word getRandomWord(int wordId=-1);
        /**
         * @brief isAddWordExist 当前用户是否已经添加这个单词
         * @param wordId 单词id
         * @param userId 用户id
         * @return 存在：true； 不存在：false
         */
        bool isAddWordExist(int wordId, int userId);
        /**
         * @brief addWord 添加自己单词
         * @param word 单词对象
         * @param userID 用户id
         * @return 成功返回ture，失败返回false
         */
        bool addWord(int wordId, int userId);

        /**
         * @brief queryWordById 通过单词id查询单词详细信息
         * @param wordId 单词id
         * @return 单词详细信息
         */
        Word queryWordInfoById(int wordId);

        /**
         * @brief getMyselfWords 获取自己的单词列表
         * @return 返回单词容器
         */
        QVector<Word> getMyselfWords(int userId);

        /**
         * @brief FindEnglish 根据汉语查英语
         * @param Chinese 汉语
         */
        Word FindEnglish(QString Chinese);
        /**
         * @brief FindChinese 根据英语查汉语
         * @param english 英语
         * @return
         */
        Word FindChinese(QString english);
private:
      void connectAndOpenDb();
      QString parseToUtf8(QString text) ;
      QString AddPassword();
private:
    QSqlDatabase db;
    QString m_dbName;
    QString m_host;
    QString m_user;
    QString m_pwd;
    int m_port;
};

#endif // WORDSERVICE_H
