#include "worker.h"
#include "ui_worker.h"
#include <QDialog>
//#include "workerlist.h"

Worker::Worker(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Worker)
{
    ui->setupUi(this);
    //添加文字
    ui->label->setText("liaofanglin");

    //设置组件大小 - 固定
    this->setFixedSize(295,25);

    //设定窗口透明
    this->setAttribute(Qt::WA_TranslucentBackground);

    //设置字体
    ui->label->setStyleSheet("font-size:18px; font-family:PingFang Sc; color:white");

    //设置窗口为无边框
    this->setWindowFlag(Qt::FramelessWindowHint);

   // WorkerList* worklist = new WorkerList();

//    //设置按钮控制开发人员名单的显示
//    connect(ui->toolButton, &QToolButton::clicked, this, [=](){
//        if (worklist->isVisible() == false)
//        {
//            worklist->setVisible(true);
//        }
//        else
//        {
//            worklist->setVisible(false);
//        }
//    });
}

Worker::~Worker()
{
    delete ui;
}

