#include "forgetpassword.h"
#include "ui_forgetpassword.h"
#include<QPainter>
#include<QDebug>
#include<QHBoxLayout>
#include<QCalendarWidget>
ForgetPassword::ForgetPassword(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ForgetPassword)
{
    ui->setupUi(this);

    this->setWindowFlags(Qt::FramelessWindowHint);//去掉边框

    connect(ui->btnClose,&QToolButton::clicked,[=](){
        this->close();
    });
    //最小化
    connect(ui->btnMin,&QToolButton::clicked,this,&QWidget::showMinimized);


    connect(ui->btnChange,&QPushButton::clicked,[=](){
        this->ChangePassword();
    });

    QToolButton* birthdayButton = new QToolButton(this);
    birthdayButton->setAutoRaise(true);
    birthdayButton->setFixedSize(45, 45);
    birthdayButton->setIcon(QIcon(QPixmap(":/imagess/time.jpg")));
    birthdayButton->setCursor(Qt::PointingHandCursor);
    QHBoxLayout* hlayout1 = new QHBoxLayout();
    hlayout1->addStretch();          //必须加这句话
    hlayout1->addWidget(birthdayButton);
    hlayout1->setContentsMargins(0, 0, 0, 0);    //必须加这句话
    ui->lineEdit_birthdate->setLayout(hlayout1);
    //添加日历并将其与对应按钮连接起来
    QCalendarWidget* calendar = new QCalendarWidget(this);
    calendar->move(50,485);
    calendar->setFixedSize(300,300);
    calendar->setVisible(false);
    connect(birthdayButton, &QToolButton::clicked, this, [=](){
        if (calendar->isVisible() == false)
        {
            calendar->setVisible(true);
        }
        else
        {
            calendar->setVisible(false);
        }
    });

    QDate* date = new QDate();
    connect(calendar, &QCalendarWidget::clicked, this, [=](){
        *date = calendar->selectedDate();
        QString str_temp = QString("%1-%2-%3").arg(QString::number(date->year())).arg(QString::number(date->month())).arg(QString::number(date->day()));
        ui->lineEdit_birthdate->setText(str_temp);
        calendar->close();
    });
    QToolButton* passwordButton = new QToolButton(this);
    passwordButton->setFixedSize(45, 45);
    passwordButton->setAutoRaise(true);
    passwordButton->setCursor(Qt::PointingHandCursor);
    passwordButton->setIcon(QIcon(QPixmap(":/imagess/notshou.jpg")));
    QHBoxLayout* hlayout2 = new QHBoxLayout();
    hlayout2->addStretch();
    hlayout2->addWidget(passwordButton);
    hlayout2->setContentsMargins(0, 0, 0, 0);
    ui->lineEdit_password->setLayout(hlayout2);
    //设置按钮控制密码是否明文显示
    connect(passwordButton, &QToolButton::clicked, this, [=](){
        if (ui->lineEdit_password->echoMode() == QLineEdit::Password)
        {
            ui->lineEdit_password->setEchoMode(QLineEdit::Normal);
            passwordButton->setIcon(QIcon(QPixmap(":/imagess/show.jpg")));
        }
        else
        {
            ui->lineEdit_password->setEchoMode(QLineEdit::Password);
            passwordButton->setIcon(QIcon(QPixmap(":/imagess/notshou.jpg")));
        }
    });

    //在lintEdit_repassword里添加按钮
    QToolButton* repasswordButton = new QToolButton(this);
    repasswordButton->setFixedSize(45, 45);
    repasswordButton->setCursor(Qt::PointingHandCursor);
    repasswordButton->setAutoRaise(true);
    repasswordButton->setIcon(QIcon(QPixmap(":/imagess/notshou.jpg")));
    QHBoxLayout* hlayout3 = new QHBoxLayout();
    hlayout3->addStretch();
    hlayout3->addWidget(repasswordButton);
    hlayout3->setContentsMargins(0, 0, 0, 0);
    ui->lineEdit_repassword->setLayout(hlayout3);
    //设置按钮控制密码是否明文显示
    connect(repasswordButton, &QToolButton::clicked, this, [=](){
        if (ui->lineEdit_repassword->echoMode() == QLineEdit::Password)
        {
            ui->lineEdit_repassword->setEchoMode(QLineEdit::Normal);
            repasswordButton->setIcon(QIcon(QPixmap(":/imagess/show.jpg")));
        }
        else
        {
            ui->lineEdit_repassword->setEchoMode(QLineEdit::Password);
            repasswordButton->setIcon(QIcon(QPixmap(":/imagess/notshou.jpg")));
        }
    });

}
ForgetPassword::~ForgetPassword()
{
    delete ui;
}
void ForgetPassword::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    //painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(":/imagess/bg.jpg"));
    /*QPen pen;
    painter.setPen(pen);
    QBrush brush;
    brush.setColor(QString("red"));
    brush.setStyle(Qt::Dense4Pattern);
    painter.setBrush(brush);
    painter.setRenderHint(QPainter::HighQualityAntialiasing);
    painter.drawRect(0,525,this->width(),335);*/

    //painter.drawPixmap(0,525,this->width(),355,QPixmap(":/images/bg222.png"));
}

void ForgetPassword::ChangePassword()
{
    QString m_email;
    QString m_birthday;
    QString m_password;
    QString m_passwordagain;
    m_email=ui->lineEdit_email->text();
    m_birthday=ui->lineEdit_birthdate->text();
    m_password=ui->lineEdit_password->text();
    m_passwordagain=ui->lineEdit_repassword->text();
    if(!this->userservice.verifyAccoutAndBirthday(m_email,m_birthday))
    {
        error=new Errow(this,"用户名与密保不匹配！");
        error->show();
    }
    else {
        if(m_password!=m_passwordagain)
        {
            error=new Errow(this,"两次密码输入不一样！");
            error->show();
        }
        else {
            qDebug()<<"进入修改";
            user=new User();
            user->account=m_email;
            user->birthday=m_birthday;
            user->password=m_password;
            if(this->userservice.modifyPassword(user))
            {
                error=new Errow(this,"修改成功！");
                error->show();
                this->close();
            }
        }
    }
}
void ForgetPassword::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = true;
        //获得鼠标的初始位置
        mouseStartPoint = event->globalPos();
        //mouseStartPoint = event->pos();
        //获得窗口的初始位置
        windowTopLeftPoint = this->frameGeometry().topLeft();
    }
}
void ForgetPassword::mouseMoveEvent(QMouseEvent *event)
{
    if(m_bDrag)
    {
        //获得鼠标移动的距离
        QPoint distance = event->globalPos() - mouseStartPoint;
        //QPoint distance = event->pos() - mouseStartPoint;
        //改变窗口的位置
        this->move(windowTopLeftPoint + distance);
    }
}
void ForgetPassword::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = false;
    }
}


