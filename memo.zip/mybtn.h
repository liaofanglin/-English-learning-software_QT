#ifndef MYBTN_H
#define MYBTN_H

#include <QWidget>
#include<QPushButton>
namespace Ui {
class mybtn;
}
class mybtn : public QPushButton
{
    Q_OBJECT
public:
    explicit mybtn(QWidget *parent ,QString str);
    ~mybtn();
private:
    Ui::mybtn *ui;
};
#endif // MYBTN_H

