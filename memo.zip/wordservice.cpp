#include <QDebug>
#include <QTextCodec>
#include "wordservice.h"
#include "word.h"
#include<QMessageBox>
#include<QDir>
#include<QFile>
WordService::WordService()
{
    m_dbName = "Danci.db";   // 数据库名
    m_host = "localhost";  // 主机
    m_user = "root"; // 登录用户名
    m_pwd = "123456"; // 登录密码
   // m_port=3301;
}
Word WordService::getRandomWord(int wordId)
{
    connectAndOpenDb();
    QString sql = QString("SELECT id,word,translate FROM words WHERE id != %1 ORDER BY RANDOM() LIMIT 1;").arg(wordId);
    qDebug()<<sql;
    // 创建查询对象
    QSqlQuery query(sql);
    // 执行
    query.exec();
    Word objWord;
    if(query.first()) {
        objWord.id = query.value(0).toInt();
        objWord.word = query.value(1).toString();
        objWord.translate = parseToUtf8(query.value(2).toString());
    }
    // 关闭连接
    db.close();
    return objWord;
}

// 当前用户是否已经添加这个单词
bool WordService::isAddWordExist(int wordId, int userId)
{
    connectAndOpenDb();
    QString sql = QString("SELECT COUNT(*) FROM   WHERE admin_id=%1 and word_id=%2").arg(userId).arg(wordId);
    QSqlQuery query(sql);
    query.exec();
    // 执行
    int res;
    if(query.first()) {
        res = query.value(0).toInt();
    }
    db.close();
    return res;
}

// 添加自己单词
bool WordService::addWord(int wordId, int userId)
{
    connectAndOpenDb();
    QString sql = QString("INSERT INTO add_words (admin_id, word_id) VALUES (%1, %2)").arg(userId).arg(wordId);
    QSqlQuery query;
    bool res = query.exec(sql);
    db.close();
    return res;
}

// 通过单词id查询单词详细信息
Word WordService::queryWordInfoById(int wordId)
{
    connectAndOpenDb();
    QString sql = QString("SELECT id,word,translate FROM words WHERE id=%1;").arg(wordId);
    // 创建查询对象
    QSqlQuery query(sql);
    // 执行
    query.exec();
    Word objWord;
    if(query.first()) {
        objWord.id = query.value(0).toInt();
        objWord.word = query.value(1).toString();
        objWord.translate = parseToUtf8(query.value(2).toString());
    }
    // 关闭连接
    db.close();
    return objWord;
}

// 获取自己的单词列表
QVector<Word> WordService::getMyselfWords(int userId)
{
    connectAndOpenDb();
    QString sql = QString("SELECT words.id, word, translate FROM add_words "
                          "INNER JOIN words ON add_words.word_id=words.id "
                          "WHERE admin_id = %1").arg(userId);
    QSqlQuery query(sql);
    query.exec();
    QVector<Word> list;
    while (query.next()) {
        Word objWord;
        objWord.id = query.value(0).toInt();
        objWord.word = query.value(1).toString();
        objWord.translate = parseToUtf8(query.value(2).toString());
        list.append(objWord);
    }
    db.close();
    return list;
}

Word WordService::FindEnglish(QString Chinese)
{
     connectAndOpenDb();
     Word word;
     QString sql=QString("SELECT id,word,translate FROM words WHERE translate like '%%1%'").arg(Chinese);
     QSqlQuery query(sql);
     query.exec();
     if(query.first()) {
         word.id = query.value(0).toInt();
         word.word = query.value(1).toString();
         word.translate = parseToUtf8(query.value(2).toString());
     }
     db.close();
     return word;
}

Word WordService::FindChinese(QString english)
{
    connectAndOpenDb();
    Word word;
    QString sql=QString("SELECT id,word,translate FROM words WHERE word ='%1'").arg(english);
    QSqlQuery query(sql);
    query.exec();
    if(query.first()) {
        word.id = query.value(0).toInt();
        word.word = query.value(1).toString();
        word.translate = parseToUtf8(query.value(2).toString());
    }
    db.close();
    return word;
}

// 创建数据库连接对象并打开
void WordService::connectAndOpenDb()
{
    // 创建数据库连接对象
    if(QSqlDatabase::contains("qt_sql_default_connection"))
    {
        db=QSqlDatabase::database("qt_sql_default_connection");
    }
    else {
        db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName(m_dbName);
        db.setUserName(m_user);
        db.setPassword(m_pwd);
    }
    if(!db.open())
    {
         qDebug()<<"error to open";
    }
    else {

    }
}

QString WordService::parseToUtf8(QString text)
{
    QByteArray ba=text.toUtf8();
    return QString::fromUtf8(ba.data(),strlen(ba.data()));
}
QString WordService::AddPassword()
{
    QDir dir;
    QString str=dir.currentPath()+QString("/sqlpwd.txt");
    QFile passFile(str);
    passFile.open(QIODevice::ReadOnly | QIODevice::Text);
    QTextStream qts(&passFile);
    QString m_password;
    qts>>m_password;
    return  m_password;
}


