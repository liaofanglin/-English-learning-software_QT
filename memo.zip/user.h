#ifndef USER_H
#define USER_H


#include<QDate>
class  User
{
public:
    User();
    /**
     * @brief User
     * @param user 用户名
     * @param password 密码
     * @param birthday 密保
     * @param id id号
     * @param time 注册时间
     */
    User(QString user,QString password,QString birthday,int id,QDateTime time);
    QString account;//用户名
    QString password;//密码
    QString birthday;//密保
    QDateTime rigster_datetime;
    int id;
};

#endif // USER_H

