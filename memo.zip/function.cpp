#include<QPainter>
#include <QDateTime>
#include <QMessageBox>
#include <QDebug>
#include <QVector>
#include "function.h"
#include "ui_function.h"
#include "userservice.h"
#include "user.h"
#include "wordservice.h"
#include "word.h"

Function::Function(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Function)
{
    ui->setupUi(this);
    //this->setWindowFlags(Qt::FramelessWindowHint);//去掉边框
    ui->btnFillout->setStyleSheet("background-color:#FF67B3;color:white;border-radius:25px");
    ui->btn_find->setStyleSheet("background-color:#FF67B3;color:white;border-radius:25px");
    ui->btnLexicon->setStyleSheet("background-color:#32DFF2;color:white;border-radius:25px");
    //ui->label->setStyleSheet("background-image:url(:/imagess/nter.png)");
    Word word;
    FillOut *fillout=new FillOut(nullptr,1,word);
    UnfamilyWord *unfamily=new UnfamilyWord(nullptr);
    FindWord *findword=new FindWord(nullptr);
    m_bDrag=false;
    //最小化
    //connect(ui->btnMin,&QToolButton::clicked,this,&QWidget::showMinimized);
    //connect(ui->btnClose,&QToolButton::clicked,this,[=](){
        //this->close();
    //});

    connect(ui->btnFillout,&QToolButton::clicked,this,[=](){
        delete unfamily;
        delete findword;
        fillout->move(this->x(),this->y());
        this->close();
        fillout->show();
    });
    connect(ui->btnLexicon,&QToolButton::clicked,this,[=](){
        delete fillout;
        delete findword;
        unfamily->move(this->x(),this->y());
        this->close();
        unfamily->show();
    });
    connect(ui->btn_find,&QToolButton::clicked,this,[=](){
        delete unfamily;
        delete fillout;
        findword->move(this->x(),this->y());
        this->close();
        findword->show();
    });
}
Function::~Function()
{
    delete ui;
}
void Function::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = true;
        //获得鼠标的初始位置
        mouseStartPoint = event->globalPos();
        //mouseStartPoint = event->pos();
        //获得窗口的初始位置
        windowTopLeftPoint = this->frameGeometry().topLeft();
    }
}
void Function::mouseMoveEvent(QMouseEvent *event)
{
    if(m_bDrag)
    {
        //获得鼠标移动的距离
        QPoint distance = event->globalPos() - mouseStartPoint;
        //QPoint distance = event->pos() - mouseStartPoint;
        //改变窗口的位置
        this->move(windowTopLeftPoint + distance);
    }
}
void Function::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = false;
    }
}
void Function::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(":/images/bg.jpg"));
}

void Function::reshow()
{
    this->show();
}

