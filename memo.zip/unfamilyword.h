#ifndef UNFAMILYWORD_H
#define UNFAMILYWORD_H

#include <QWidget>
#include<wordservice.h>
#include"word.h"
#include"information.h"
#include"mybtn.h"
#include<QMouseEvent>
#include"errow.h"
namespace Ui {
class UnfamilyWord;
}

class UnfamilyWord : public QWidget
{
    Q_OBJECT

public:
    explicit UnfamilyWord(QWidget *parent = nullptr);
    WordService wordservice;
    QVector<Word>m_word;
    ~UnfamilyWord();
      int j=0;//记录页数
      void mousePressEvent(QMouseEvent *event);
      void mouseMoveEvent(QMouseEvent *event);
      void mouseReleaseEvent(QMouseEvent *event);
      bool m_bDrag;
      QPoint mouseStartPoint;
      QPoint windowTopLeftPoint;

private:
    Ui::UnfamilyWord *ui;
signals:

};

#endif // UNFAMILYWORD_H

