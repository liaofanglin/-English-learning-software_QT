#ifndef FORGETPASSWORD_H
#define FORGETPASSWORD_H

#include <QWidget>
#include"userservice.h"
#include"errow.h"
#include<QMouseEvent>
namespace Ui {
class ForgetPassword;
}

class ForgetPassword : public QWidget
{
    Q_OBJECT

public:
    explicit ForgetPassword(QWidget *parent = nullptr);
    ~ForgetPassword();
    void paintEvent(QPaintEvent *event);
    Errow *error;
    UserService userservice;
    User *user;
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    bool m_bDrag;
    QPoint mouseStartPoint;
    QPoint windowTopLeftPoint;
    void ChangePassword();

private:
    Ui::ForgetPassword *ui;
};

#endif // FORGETPASSWORD_H

