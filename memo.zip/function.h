#ifndef FUNCTION_H
#define FUNCTION_H

#include <QWidget>
#include<QMouseEvent>
#include"findword.h"
#include"fillout.h"
#include"unfamilyword.h"

namespace Ui {
class Function;
}

class Function : public QWidget
{
    Q_OBJECT

public:
    explicit Function(QWidget *parent = nullptr);
    ~Function();
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    bool m_bDrag;
    QPoint mouseStartPoint;
    QPoint windowTopLeftPoint;
    void paintEvent(QPaintEvent *event);
    //自定义槽函数 显示该界面
    void reshow();
private slots:

private:
    Ui::Function *ui;
};

#endif // FUNCTION_H

