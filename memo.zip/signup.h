#ifndef SIGNUP_H
#define SIGNUP_H
#include <QWidget>
#include <QVector>
#include <QFrame>
#include"errow.h"
#include"information.h"
#include"forgetpassword.h"//忘记密码类
#include"registerperson.h"//注册类
#include"function.h"//登录成功进入的功能类
#include<QMouseEvent>
#include"userservice.h"
#include"worker.h"
namespace Ui {
class SignUp;
}

class SignUp : public QWidget
{
    Q_OBJECT

public:
    explicit SignUp(QWidget *parent = nullptr);
    ~SignUp();
    //QVector<Person*>m_Vector;//创建一个容器用于储存数据库中的用户信息
    UserService m_userservice;
    Errow *p_Error;//错误信息容器指针
    Worker *p_Worker;//制作人员容器指针
    ForgetPassword *p_Forget;//忘记密码类型的指针  用于存储忘记密码对象的地址
    RegisterPerson *p_Register;//注册类型的指针
    Function *p_Function;//功能区的指针
    QString m_fixedUser;//用户选择记住密码后，用该变量存储该用户的账户
    int type;//1为选择了记住密码 0为未选择
    /*
     * 若选择了记住密码 则根据m_fixedUser寻找该用户的密码
     * 该函数用于寻找该用户的密码
     * 返回值为该用户的密码
    */
    QString FindPersonPassword(QString m_user);
    void SaveText();//创建文本文档 用于存储 是否选择了记住密码 以及该用户的账户 1为选择  0为未选择
    bool ReadText();//读取文本文档 检查是否选择了记住密码
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    bool m_bDrag;
    QPoint mouseStartPoint;
    QPoint windowTopLeftPoint;
private:
    Ui::SignUp *ui;
private slots:
    //响应点击“还没有账号”按钮事件
    void toRegist();
    //响应点击“忘记密码”按钮事件
    void toForgetPassword();
    //响应点击“登录”按钮事件
    void toLogin();
//    //响应点击制作人员按钮事件
    void showWorker();
    void on_btn_minWindow_clicked();
    void on_btn_closeWindow_clicked();
};

#endif // SIGNUP_H

