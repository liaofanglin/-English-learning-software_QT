#ifndef TYPE_H
#define TYPE_H

enum type{type_Rect, type_Line, type_Pen, type_Ellipse, type_Polygon};

#endif // TYPE_H
