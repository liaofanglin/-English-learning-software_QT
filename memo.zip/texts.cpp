#include "texts.h"

#include <QVector>

texts::texts()
{
  ;
}

void texts::paint(QPainter &paint)
{
    paint.setPen(QPen(color, width));
    paint.setBrush(brush);
    //paint.drawText(start.x(), start.y(),end.x() - start.x(), end.y() - start.y());
    //paint.drawText(start,end);
}

int texts::get_typeid()
{
    return 6;
}
