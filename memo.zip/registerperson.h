#ifndef REGISTERPERSON_H
#define REGISTERPERSON_H
#include <QWidget>
#include"userservice.h"
#include <QPushButton>
#include <QLineEdit>
#include<QMouseEvent>
#include"errow.h"
namespace Ui {
class RegisterPerson;
}

/**
 * @brief 注册界面类
 */
class RegisterPerson : public QWidget
{
    Q_OBJECT

public:
    explicit RegisterPerson(QWidget *parent = nullptr);
    ~RegisterPerson();
    User *m_newPerson;       //注册的新用户
    UserService m_userService;
    void AddPerson();
    Errow *errow;
    //QPushButton* createLineEditRightButton(QLineEdit *edit);
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *event);
    bool m_bDrag;
    QPoint mouseStartPoint;
    QPoint windowTopLeftPoint;
private:
    Ui::RegisterPerson *ui;
};

#endif // REGISTERPERSON_H

