#include "work.h"
#include "ui_work.h"

Work::Work(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Work)
{
    ui->setupUi(this);
}

Work::~Work()
{
    delete ui;
}
