#ifndef TEXTS_H
#define TEXTS_H

#include <shape.h>
#include <QPainter>

class texts : public Shape
{
public:
    texts();
private:
    virtual void paint(QPainter& paint) override;
    virtual int get_typeid() override;

    QVector<QString>  _text;//文字集合
    QVector<QPoint>  _tpoint;//文字位置集合
};

#endif // TEXTS_H
