#include "mybtn.h"
#include "ui_mybtn.h"

mybtn::mybtn(QWidget *parent,QString str) :
    QPushButton(parent),
    ui(new Ui::mybtn)
{
    ui->setupUi(this);
    ui->toolButton->setAutoRaise(true);
    ui->label->setText(str);
    this->setStyleSheet("background-color:#F0F0F0;border-width:2px;border-style:none none solid none;border-color:#DEDEDE;");
}

mybtn::~mybtn()
{
    delete ui;
}

