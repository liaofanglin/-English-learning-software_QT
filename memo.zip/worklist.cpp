#ifndef WORKERLIST_H
#define WORKERLIST_H

#include "workerlist.h"
#include "ui_workerlist.h"
#include <QListWidgetItem>

WorkerList::WorkerList(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::WorkerList)
{
    ui->setupUi(this);

    //设定窗口大小
    this->setFixedSize(295, 375);

    //设置窗口无边框
    this->setWindowFlag(Qt::FramelessWindowHint);

    connect(ui->btnClose,&QToolButton::clicked,[=](){
        this->close();
    });

    //添加文本内容及设定格式
    QListWidgetItem* item1 = new QListWidgetItem(" 制作人员");
    item1->setFont(QFont("PingFang SC",16));
    ui->listWidget_1->addItem(item1);
    ui->listWidget_1->setStyleSheet("color:#4D4D4D;");

    QListWidgetItem* item2 = new QListWidgetItem(" 刘海龙\t组长");
    item2->setFont(QFont("PingFang SC", 14));
    ui->listWidget_2->addItem(item2);
    ui->listWidget_2->setStyleSheet("color:#4D4D4D;margin-bottom:5px;");
    QListWidgetItem* item3 = new QListWidgetItem(" 冀咏雪");
    item3->setFont(QFont("PingFang SC", 14));
    ui->listWidget_2->addItem(item3);


    QListWidgetItem* item4 = new QListWidgetItem(" 李硕");
    item4->setFont(QFont("PingFang SC", 14));
    ui->listWidget_2->addItem(item4);

    QListWidgetItem* item5 = new QListWidgetItem(" 刘佳惠");
    item5->setFont(QFont("PingFang SC", 14));
    ui->listWidget_2->addItem(item5);
}

WorkerList::~WorkerList()
{
    delete ui;
}

