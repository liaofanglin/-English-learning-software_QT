#ifndef MYNOTE_H
#define MYNOTE_H

#include <QMainWindow>
#include <QFileDialog>//文件对话框
#include <QFile>//文件类
#include <QFileInfo>//文件信息类
#include <QDir>//目录类
#include <QDebug>//调试类,用来打印输出
#include <QString>//字符串类
#include <QMessageBox>//消息对话框
//#include <QPrinter>//打印机类
//#include <QPrintDialog>//打印对话框
//#include <QPageSetupDialog>//页面设置对话框
#include <QUndoStack>//存放撤销命令和反撤销命令的类
#include <QApplication>//应用类
#include <QClipboard>//剪切板类
#include <QDateTime>//日期时间类
#include <QFontDialog>//字体对话框
#include <QColorDialog>//颜色对话框
#include <QDesktopServices>//针对操作系统的桌面服务应用的类,可以打开本地浏览器
#include <QUrl>//网址类
#include <QCloseEvent>//关闭事件

namespace Ui {
class mynote;
}

class mynote : public QMainWindow
{
    Q_OBJECT

public:
    explicit mynote(QWidget *parent = nullptr);
    ~mynote();

private:
    Ui::mynote *ui;
    QString _filename;//为文件保存提供入口
    QUndoStack *_undoStack;//定义一个撤销对象指针
    QUndoStack *_noUndoStack;//定义一个反撤销对象指针
    void closeEvent(QCloseEvent *);//声明关闭事件函数
    int closeMessageBox(QString Title, QString text);//关闭记事本时,弹出的消息对话框,参数是对话框的标题、正文内容
private slots:
    //文件菜单
    void newfile();//新建文件
    QString openfile();//打开文件
    void savefile();//保存文件
    void saveAsfile();//另存文件
    //void pageSetup();//页面设置
    //void printfile();//打印文件
    void closenotepad();//直接退出记事本

    //编辑菜单
    void _repeal();//撤销
    void _norepeal();//反撤销
    void _cut();//剪切
    void _copy();//复制
    void _paste();//粘贴
    void _dateTime();//显示日期时间到文本输入框
    //格式菜单
    void _font();//设置字体
    void _color();//设置字体颜色
    //帮助菜单
    void showHelp();//记事本帮助网页
    void inRegardTo();//关于记事本对话框
};

#endif // MYNOTE_H
