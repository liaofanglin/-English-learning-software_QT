#include "login.h"
#include "ui_login.h"
#include<QDebug>
#include <mainwindow.h>
#include <mynote.h>
#include <database.h>
#include <function.h>
login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
}

login::~login()
{
    delete ui;
    this->setWindowTitle("单词笔记本");//修改窗口标题

}

void login::on_start_clicked()
{
    Function *word=new Function;
    word->show();
}

void login::on_paint_clicked()
{
    MainWindow *paint=new MainWindow;
    paint->show();
}

void login::on_note_clicked()
{
    mynote *note=new mynote;
    note->show();
}


void login::on_notebook_clicked()
{
    database *notebook=new database;
    notebook->show();
}
