#include "signup.h"
#include "ui_signup.h"
#include <QFile>
#include <QTextStream>
#include <login.h>

#include<QDir>
#include<QHBoxLayout>

SignUp::SignUp(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SignUp)
{
    ui->setupUi(this);
    //设置窗口无边框
    setWindowFlags(Qt::FramelessWindowHint);
    //读取密码储存文件
    QFile passFile(tr("pass.word"));
    if(passFile.exists())
    {
        passFile.open(QIODevice::ReadOnly | QIODevice::Text);

        QTextStream qts(&passFile);

        qts.setCodec("UTF-8");
        qDebug()<<"文件";

        ui->line_username->setText(qts.readLine());
        ui->line_password->setText(qts.readLine());

    }
    passFile.close();
    this->ReadText();
    //链接注册按钮事件
    connect(ui->btn_toRegist,SIGNAL(clicked()),this,SLOT(toRegist()));
    //链接忘记密码按钮事件
    connect(ui->btn_forgetPass,SIGNAL(clicked()),this,SLOT(toForgetPassword()));
    //链接登录按钮事件
    connect(ui->btn_login,SIGNAL(clicked()),this,SLOT(toLogin()));
    m_bDrag=false;

    //在lintEdit_password里添加按钮
    QToolButton* passwordButton = new QToolButton(this);
    passwordButton->setFixedSize(45, 45);
    passwordButton->setAutoRaise(true);
    passwordButton->setCursor(Qt::PointingHandCursor);
    passwordButton->setIcon(QIcon(QPixmap(":/imagess/notshou.jpg")));
    QHBoxLayout* hlayout2 = new QHBoxLayout();
    hlayout2->addStretch();
    hlayout2->addWidget(passwordButton);
    hlayout2->setContentsMargins(0, 0, 0, 0);
    ui->line_password->setLayout(hlayout2);
    //设置按钮控制密码是否明文显示
    connect(passwordButton, &QToolButton::clicked, this, [=](){
        if (ui->line_password->echoMode() == QLineEdit::Password)
        {
            ui->line_password->setEchoMode(QLineEdit::Normal);
            passwordButton->setIcon(QIcon(QPixmap(":/imagess/show.jpg")));
        }
        else
        {
            ui->line_password->setEchoMode(QLineEdit::Password);
            passwordButton->setIcon(QIcon(QPixmap(":/imagess/notshou.jpg")));
        }
    });
}

SignUp::~SignUp()
{
    delete ui;
}

void SignUp::SaveText()
{
    QDir dir;
    QString str=dir.currentPath()+QString("/Person.txt");
    QFile passFile(str);
    passFile.open(QFile::Truncate|QIODevice::WriteOnly | QIODevice::Text);
    QTextStream qts(&passFile);
    qts.setCodec("UTF-8");
    this->type=1;
    qts << ui->line_username->text() << endl;
    qts << ui->line_password->text() << endl;
    qts << type << endl;
    passFile.close();
}

bool SignUp::ReadText()
{
    QDir dir;
    QString str=dir.currentPath()+QString("/Person.txt");
    QFile passFile(str);
    passFile.open(QIODevice::ReadOnly | QIODevice::Text);
    QTextStream qts(&passFile);
    QString m_user;
    QString m_password;
    type=0;
    qts>>m_user>>m_password>>type;
    if(type==1)
    {
        ui->check_remPass->setChecked(true);
        ui->line_username->setText(m_user);
        ui->line_password->setText(m_password);
    }

}
void SignUp::toRegist()
{
    p_Register = new RegisterPerson();
    p_Register->show();
}
void SignUp::toForgetPassword()
{
    p_Forget = new ForgetPassword();
    p_Forget->show();
}
void SignUp::toLogin()
{
    if(ui->line_username->text().length() == 0)
    {
        QString str(tr("账号为空！"));
        p_Error = new Errow(this,str);
        p_Error->show();
    }
    else if(ui->line_password->text().length() == 0)
    {
        QString str(tr("密码为空！"));
        p_Error = new Errow(this,str);
        p_Error->show();
    }
    else if(ui->line_username->text().contains(' ',Qt::CaseSensitive))
    {
        QString str(tr("账户名中有空格！"));
        p_Error = new Errow(this,str);
        p_Error->show();
    }
    else if(!ui->line_username->text().contains('@',Qt::CaseInsensitive))
    {
        QString str(tr("账户名非邮箱！"));
        p_Error = new Errow(this,str);
        p_Error->show();
    }
    else
    {
        m_user->account = ui->line_username->text();
        m_user->password = ui->line_password->text();

        if(!(m_userservice.login(m_user)))
        {
            QString str(tr("账号密码错误！"));
            p_Error = new Errow(this,str);
            p_Error->show();
        }
        else
        {
            if(ui->check_remPass->isChecked())
            {
                this->SaveText();
            }
            else {
                QDir dir;
                QString str=dir.currentPath()+QString("/Person.txt");
                QFile passFile(str);

                passFile.open(QFile::Truncate|QIODevice::WriteOnly | QIODevice::Text);
            }
            login *lgup=new login;
            lgup->show();
            this->close();
        }

    }
}

void SignUp::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = true;
        //获得鼠标的初始位置
        mouseStartPoint = event->globalPos();
        //mouseStartPoint = event->pos();
        //获得窗口的初始位置
        windowTopLeftPoint = this->frameGeometry().topLeft();
    }
}

void SignUp::mouseMoveEvent(QMouseEvent *event)
{
    if(m_bDrag)
    {
        //获得鼠标移动的距离
        QPoint distance = event->globalPos() - mouseStartPoint;
        //QPoint distance = event->pos() - mouseStartPoint;
        //改变窗口的位置
        this->move(windowTopLeftPoint + distance);
    }
}

void SignUp::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = false;
    }
}

void SignUp::showWorker()
{
    p_Worker = new Worker();
    p_Worker->show();
}

void SignUp::on_btn_minWindow_clicked()
{
    this->showMinimized();
}

void SignUp::on_btn_closeWindow_clicked()
{
    this->close();
}
