#include "database.h"
#include "ui_database.h"
#include <qDebug>
#include<QSqlError>
#include<QSqlQueryModel>
#include<QTableView>
#include"eitequerymodel.h"
#include<QSqlQuery>


database::database(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::database)
{
    ui->setupUi(this);
    qDebug()<<QSqlDatabase::drivers();
    QString aFile="./database.db";
    if(aFile.isEmpty())
    {
        qDebug()<<"文件加载失败！";
        return;
    }
    db=QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(aFile);
    if(!db.open())
    {
        qDebug()<<"Error failed to open "<<db.lastError();
    }
    QSqlQuery query(db);
    QString sqlCreate=QString("create table staff(id integer primary key autoincrement,"
                              "name varchar char(20),"
                              "age int,"
                              "address varchar char(40),"
                              "salary int);");
    query.exec(sqlCreate);
    QString sqlInsert=QString ("insert into staff (name,age,address,salary) values('2022-01-01',0,'0',0);");
    qDebug()<<"success";
    query.exec(sqlInsert);
    if(!db.open())
    {
        qDebug()<<"Error failed to Insert"<<db.lastError();
    }
    //使用QSqlQueryModel来高效查询数据库的操作
    //[1]创建QSqlQueryModel对象，并设置相关的表头信息
    //QSqlQueryModel* model=new QSqlQueryModel;
    //创建一个模型对象
    //void MainWindow::on_pushButton_clicked()
//{
    QSqlQueryModel* model=new QSqlQueryModel ;

    model->setQuery("SELECT id,name,age,address,salary FROM staff");

    //执行sqlQuery语句将查询出来的结果转换成model对象
    //model->setQuery("select id,name,age,address,salary from staff");
    //根据需求设置表头信息

    model->setHeaderData(0,Qt::Horizontal,"Id");
    model->setHeaderData(1,Qt::Horizontal,"日期");
    model->setHeaderData(2,Qt::Horizontal,"所用时长");
    model->setHeaderData(3,Qt::Horizontal,"单词总数");
    model->setHeaderData(4,Qt::Horizontal,"连续打卡天数");

    //给ui控件设置一个模型
    QTableView * view=new QTableView(ui->centralwidget);
    view->setFixedSize(QSize(this->width(),this->height()));//设置大小
    view->setModel(model);//相当于将数据联动到ui控件上
    //将view显示出来
    //QSqlQuery query =model->query();
    view->show();
    qDebug()<<"success";

    eiteQuerymodel* model1=new eiteQuerymodel ;

    model1->setQuery("SELECT id,name,age,address,salary FROM staff");

    //执行sqlQuery语句将查询出来的结果转换成model对象
    //model->setQuery("select id,name,age,address,salary from staff");
    //根据需求设置表头信息

    model1->setHeaderData(0,Qt::Horizontal,"Id");
    model1->setHeaderData(1,Qt::Horizontal,"日期");
    model1->setHeaderData(2,Qt::Horizontal,"所用时长");
    model1->setHeaderData(3,Qt::Horizontal,"单词总数");
    model1->setHeaderData(4,Qt::Horizontal,"连续打卡天数");

    //给ui控件设置一个模型
    QTableView * view1=new QTableView(ui->centralwidget);
    view1->setFixedSize(QSize(this->width(),this->height()));//设置大小
    view1->setModel(model1);//相当于将数据联动到ui控件上
    //将view显示出来
    //QSqlQuery query =model->query();
    view1->show();
    qDebug()<<"success";

}

database::~database()
{
    delete ui;
}
