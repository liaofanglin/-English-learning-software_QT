#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{

    //形状选择框架//
    QToolBar *shapeBar = this->addToolBar("Shape");
    QActionGroup *shapeGroup = new QActionGroup(shapeBar);

    QAction *act_rect = new QAction(QIcon(":/images/rect.png"),"Draw a Rect", shapeBar);
    act_rect->setCheckable(true);
    act_rect->setChecked(true);
    shapeGroup->addAction(act_rect);
    shapeBar->addAction(act_rect);

    QAction *act_line = new QAction(QIcon(":/images/line.png"),"Draw A Line", shapeBar);
    act_line->setCheckable(true);
    shapeGroup->addAction(act_line);
    shapeBar->addAction(act_line);

    QAction *act_pen = new QAction(QIcon(":/images/lines.png"), "Draw With Pen", shapeBar);
    act_pen->setCheckable(true);
    shapeGroup->addAction(act_pen);
    shapeBar->addAction(act_pen);

    QAction *act_ellipse = new QAction(QIcon(":/images/ellipse.png"), "Draw A Ellipse", shapeBar);
    act_ellipse->setCheckable(true);
    shapeGroup->addAction(act_ellipse);
    shapeBar->addAction(act_ellipse);

    QAction *act_polygon = new QAction(QIcon(":/images/Polygon.jpg"), "Draw A Polygon", shapeBar);
    act_polygon->setCheckable(true);
    shapeGroup->addAction(act_polygon);
    shapeBar->addAction(act_polygon);

    //操作选择框架
    QToolBar *operatorBar = this->addToolBar("Operator");
    QActionGroup *operatorGroup = new QActionGroup(operatorBar);
    QAction *Undo = new QAction(QIcon(":/images/undo(1).png"), "Undo", operatorBar);
    Undo->setShortcut(tr("Ctrl+Z"));
    operatorGroup->addAction(Undo);
    operatorBar->addAction(Undo);

    QAction *Redo = new QAction(QIcon(":/images/redo.jpg"), "Redo", operatorBar);
    Redo->setShortcut(tr("Ctrl+Y"));
    operatorGroup->addAction(Redo);
    operatorBar->addAction(Redo);

    QAction *Reset = new QAction(QIcon(":/images/Reset.jpg"), "Reset", operatorBar);
    Reset->setShortcut(tr("Ctrl+N"));
    operatorGroup->addAction(Reset);
    operatorBar->addAction(Reset);

    widthDial = new QDial(operatorBar);
    widthDial->setRange(1, 20);
    operatorBar->addWidget(widthDial);
    widthLabel = new QLabel("Size: 1", operatorBar);
    operatorBar->addWidget(widthLabel);

    alphaDial = new QDial(operatorBar);
    alphaDial->setRange(0, 100);
    alphaDial->setValue(100);
    operatorBar->addWidget(alphaDial);
    alphaLabel = new QLabel("Alpha: 100%", operatorBar);
    operatorBar->addWidget(alphaLabel);

    //菜单区域
    QMenu *file = menuBar()->addMenu(tr("&File"));
    QAction *newFile = new QAction(QIcon(":/images/new.png"),tr("New"), file);
    newFile->setShortcut(tr("Ctrl+N"));
    file->addAction(newFile);
    QAction *openFile = new QAction(QIcon(":/images/open.png"),tr("Open"), file);
    openFile->setShortcut(tr("Ctrl+O"));
    file->addAction(openFile);
    QAction *saveFile = new QAction(QIcon(":/images/save.png"),tr("Save"), file);
    saveFile->setShortcut(tr("Ctrl+S"));
    file->addAction(saveFile);
    QAction *saveAsFile = new QAction(QIcon(":/images/saveas.png"),tr("Save As"), file);
    saveAsFile->setShortcut(tr("Ctrl+Alt+S"));
    file->addAction(saveAsFile);
    QAction *quit = new QAction(QIcon(":/images/Quit.png"),tr("Quit"), file);
    quit->setShortcut(tr("Ctrl+Q"));
    file->addAction(quit);

    QMenu *change = menuBar()->addMenu(tr("&Change"));
    QAction *changeColor = new QAction(QIcon(":/images/color.png"),tr("Color"), change);
    changeColor->setShortcut(tr("Ctrl+C"));
    change->addAction(changeColor);
    QAction *changeBrush = new QAction(QIcon(":/images/brush.jpg"),tr("Brush"), change);
    changeBrush->setShortcut(tr("Ctrl+B"));
    change->addAction(changeBrush);
    QAction *changeWidth = new QAction(QIcon(":/images/text-width.png"),tr("Width"), change);
    changeWidth->setShortcut(tr("Ctrl+W"));
    change->addAction(changeWidth);

    //paint定义
    Paint *paint = new Paint(this);
    setCentralWidget(paint);

    //工具栏信号槽
    QObject::connect(act_rect, SIGNAL(triggered()), this, SLOT(draw_rect()));
    QObject::connect(act_line, SIGNAL(triggered()), this, SLOT(draw_line()));
    QObject::connect(act_pen, SIGNAL(triggered()), this, SLOT(draw_pen()));
    QObject::connect(act_polygon, SIGNAL(triggered()), this, SLOT(draw_polygon()));
    QObject::connect(act_ellipse, SIGNAL(triggered()), this, SLOT(draw_ellipse()));
    QObject::connect(Undo, SIGNAL(triggered()), paint, SLOT(Undo()));
    QObject::connect(Redo, SIGNAL(triggered()), paint, SLOT(Redo()));
    QObject::connect(Reset, SIGNAL(triggered()), paint, SLOT(Reset()));
    QObject::connect(Reset, SIGNAL(triggered()), this, SLOT(reset_dial()));
    QObject::connect(widthDial, SIGNAL(valueChanged(int)), paint, SLOT(set_width(int)));
    QObject::connect(widthDial, SIGNAL(valueChanged(int)), this, SLOT(change_widthLabel(int)));
    QObject::connect(alphaDial, SIGNAL(valueChanged(int)), paint, SLOT(set_alpha(int)));
    QObject::connect(alphaDial, SIGNAL(valueChanged(int)), this, SLOT(change_alphaLabel(int)));

    //菜单栏信号槽
    QObject::connect(newFile, SIGNAL(triggered()), paint, SLOT(Reset()));
    QObject::connect(openFile, SIGNAL(triggered()), paint, SLOT(open_file()));
    QObject::connect(saveFile, SIGNAL(triggered()), paint, SLOT(save_file()));

    QObject::connect(saveAsFile, SIGNAL(triggered()), paint, SLOT(saveAs_file()));
    QObject::connect(quit, SIGNAL(triggered()),this, SLOT(close()));
    QObject::connect(changeColor, SIGNAL(triggered()), this, SLOT(color_SLOT()));
    QObject::connect(changeBrush, SIGNAL(triggered()), this, SLOT(brush_SLOT()));
    QObject::connect(changeWidth, SIGNAL(triggered()), this, SLOT(width_SLOT()));

    //Paint交互信号槽
    QObject::connect(this, SIGNAL(select_shape(type)), paint, SLOT(set_shape(type)));
    QObject::connect(this, SIGNAL(color_change(QColor)), paint, SLOT(set_color(QColor)));
    QObject::connect(this, SIGNAL(brush_change(QColor)), paint, SLOT(set_brush(QColor)));
    QObject::connect(this, SIGNAL(width_change(int)), paint, SLOT(set_width(int)));
    QObject::connect(this, SIGNAL(change_straight(bool)), paint, SLOT(set_straight(bool)));
}

//信息发射
void MainWindow::keyPressEvent(QKeyEvent *k)
{
    if (k->modifiers() == Qt::ShiftModifier)
    {
        emit change_straight(true);
    }
}

void MainWindow::keyReleaseEvent(QKeyEvent *k)
{
    if (k->key() == Qt::Key_Shift)
    {
       emit change_straight(false);
    }
}

void MainWindow::color_SLOT()
{
    QColor c = QColorDialog::getColor(Qt::black);
    emit color_change(c);
}

void MainWindow::brush_SLOT()
{
    QColor c = QColorDialog::getColor(Qt::transparent);
    emit brush_change(c);
}

void MainWindow::width_SLOT()
{
    int c = QInputDialog::getInt(this, tr("Width Set"), tr("Enter the Width"), true, 1, 20, 1);
    emit width_change(c);
}

void MainWindow::draw_rect()
{
    emit select_shape(type_Rect);
}

void MainWindow::draw_line()
{
    emit select_shape(type_Line);
}

void MainWindow::draw_pen()
{
    emit select_shape(type_Pen);
}

void MainWindow::draw_polygon()
{
    emit select_shape(type_Polygon);
}

void MainWindow::draw_ellipse()
{
    emit select_shape(type_Ellipse);
}

//槽函数
void MainWindow::change_widthLabel(int w)
{
    widthLabel->setText("Size: " + QString::number(w));
}

void MainWindow::change_alphaLabel(int w)
{
    alphaLabel->setText("Alpha: " + QString::number(w) + "%");
}

void MainWindow::reset_dial()
{
    widthDial->setValue(1);
    alphaDial->setValue(100);
    widthLabel->setText("Size: 1");
    alphaLabel->setText("Alpha: 100%");
}

//其他//

MainWindow::~MainWindow()
{

}

QSize MainWindow::sizeHint() const
{
    return QSize(1500, 900);
}

