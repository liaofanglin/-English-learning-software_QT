#ifndef INFORMATION_H
#define INFORMATION_H
#endif // INFORMATION_H
#include"user.h"
extern User *m_user;


