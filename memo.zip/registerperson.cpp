#include "registerperson.h"
#include "ui_registerperson.h"
#include <QCalendarWidget>
#include <QToolButton>
#include <QCalendarWidget>
#include <QRegExp>
#include <QDebug>
#include <QString>
#include<QPainter>
RegisterPerson::RegisterPerson(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RegisterPerson)
{
    ui->setupUi(this);

    //设定窗口尺寸
    //this->setFixedSize(450, 860);

    //设置窗口为无边框
    this->setWindowFlag(Qt::FramelessWindowHint);
    connect(ui->btnClose,&QToolButton::clicked,[=](){
        this->close();
    });
    //最小化
    connect(ui->btnMin,&QToolButton::clicked,this,&QWidget::showMinimized);
    //为窗口添加背景图片
    //this->setObjectName("mainWidget");
    //this->setStyleSheet("#mainWidget{background-image:url(:/images/bg.jpg)}");

    m_newPerson=new User();
    //在lineEdit_birthdate里面添加按钮
    QToolButton* birthdayButton = new QToolButton(this);
    birthdayButton->setAutoRaise(true);
    birthdayButton->setFixedSize(45, 45);
    birthdayButton->setIcon(QIcon(QPixmap(":/imagess/time.jpg")));
    birthdayButton->setCursor(Qt::PointingHandCursor);
    QHBoxLayout* hlayout1 = new QHBoxLayout();
    hlayout1->addStretch();          //必须加这句话
    hlayout1->addWidget(birthdayButton);
    hlayout1->setContentsMargins(0, 0, 0, 0);    //必须加这句话
    ui->lineEdit_birthdate->setLayout(hlayout1);
    //添加日历并将其与对应按钮连接起来
    QCalendarWidget* calendar = new QCalendarWidget(this);
    calendar->move(50,335);
    calendar->setFixedSize(300,300);
    calendar->setVisible(false);
    connect(birthdayButton, &QToolButton::clicked, this, [=](){
        if (calendar->isVisible() == false)
        {
            calendar->setVisible(true);
        }
        else
        {
            calendar->setVisible(false);
        }
    });

    //在lintEdit_password里添加按钮
    QToolButton* passwordButton = new QToolButton(this);
    passwordButton->setFixedSize(45, 45);
    passwordButton->setAutoRaise(true);
    passwordButton->setCursor(Qt::PointingHandCursor);
    passwordButton->setIcon(QIcon(QPixmap(":/imagess/notshou.jpg")));
    QHBoxLayout* hlayout2 = new QHBoxLayout();
    hlayout2->addStretch();
    hlayout2->addWidget(passwordButton);
    hlayout2->setContentsMargins(0, 0, 0, 0);
    ui->lineEdit_password->setLayout(hlayout2);
    //设置按钮控制密码是否明文显示
    connect(passwordButton, &QToolButton::clicked, this, [=](){
        if (ui->lineEdit_password->echoMode() == QLineEdit::Password)
        {
            ui->lineEdit_password->setEchoMode(QLineEdit::Normal);
            passwordButton->setIcon(QIcon(QPixmap(":/imagess/show.jpg")));
        }
        else
        {
            ui->lineEdit_password->setEchoMode(QLineEdit::Password);
            passwordButton->setIcon(QIcon(QPixmap(":/imagess/notshou.jpg")));
        }
    });

    //在lintEdit_repassword里添加按钮
    QToolButton* repasswordButton = new QToolButton(this);
    repasswordButton->setFixedSize(45, 45);
    repasswordButton->setCursor(Qt::PointingHandCursor);
    repasswordButton->setAutoRaise(true);
    repasswordButton->setIcon(QIcon(QPixmap(":/imagess/notshou.jpg")));
    QHBoxLayout* hlayout3 = new QHBoxLayout();
    hlayout3->addStretch();
    hlayout3->addWidget(repasswordButton);
    hlayout3->setContentsMargins(0, 0, 0, 0);
    ui->lineEdit_repassword->setLayout(hlayout3);
    //设置按钮控制密码是否明文显示
    connect(repasswordButton, &QToolButton::clicked, this, [=](){
        if (ui->lineEdit_repassword->echoMode() == QLineEdit::Password)
        {
            ui->lineEdit_repassword->setEchoMode(QLineEdit::Normal);
            repasswordButton->setIcon(QIcon(QPixmap(":/imagess/show.jpg")));
        }
        else
        {
            ui->lineEdit_repassword->setEchoMode(QLineEdit::Password);
            repasswordButton->setIcon(QIcon(QPixmap(":/imagess/notshou.jpg")));
        }
    });
    //重复密码输入结束后判断密码与重复密码是否一致
    connect(ui->lineEdit_repassword, &QLineEdit::editingFinished, this, [=](){
        if (ui->lineEdit_password->text() != ui->lineEdit_repassword->text())
        {
            errow=new Errow(this,"两次密码输入不一样");
            errow->show();
        }
    });
    //正则表达式判断邮箱格式是否正确 -
    QRegExp* re = new QRegExp("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$");
    connect(ui->lineEdit_email, &QLineEdit::editingFinished, this, [=](){
        if (!re->exactMatch(ui->lineEdit_email->text()))
        {
            errow=new Errow(this,"邮箱格式不正确");
            errow->show();
        }
    });

    //将选择的日期显示在lineEdit_birthday上
    QDate* date = new QDate();
    connect(calendar, &QCalendarWidget::clicked, this, [=](){
        *date = calendar->selectedDate();
        QString str_temp = QString("%1-%2-%3").arg(QString::number(date->year())).arg(QString::number(date->month())).arg(QString::number(date->day()));
        ui->lineEdit_birthdate->setText(str_temp);
        calendar->close();
    });
    connect(ui->btn_register,&QToolButton::clicked,[=](){
        this->AddPerson();
    });

}

RegisterPerson::~RegisterPerson()
{
    delete ui;
}

void RegisterPerson::AddPerson()
{

    //将所有数据传给m_newPerson
    m_newPerson->account = ui->lineEdit_email->text();
    m_newPerson->password = ui->lineEdit_password->text();
    m_newPerson->birthday = ui->lineEdit_birthdate->text();
    //点击注册按钮验证信息

        //若该账户已存在
        if (m_userService.isAccountExist(m_newPerson->account))
        {
            errow=new Errow(this,"账户已存在");
            errow->show();
        }
        //若该账户不存在，则进一步判断注册是否成功
        else
        {
            //注册不成功
            if (!m_userService.registerUser(m_newPerson))
            {
                errow=new Errow(this,"注册失败");
                errow->show();
            }
            //注册成功
            else
            {
                qDebug() << "注册成功";     //看情况用什么替换
                 this->close();
            }
        }

}
void RegisterPerson::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = true;
        //获得鼠标的初始位置
        mouseStartPoint = event->globalPos();
        //mouseStartPoint = event->pos();
        //获得窗口的初始位置
        windowTopLeftPoint = this->frameGeometry().topLeft();
    }
}

void RegisterPerson::mouseMoveEvent(QMouseEvent *event)
{
    if(m_bDrag)
    {
        //获得鼠标移动的距离
        QPoint distance = event->globalPos() - mouseStartPoint;
        //QPoint distance = event->pos() - mouseStartPoint;
        //改变窗口的位置
        this->move(windowTopLeftPoint + distance);
    }
}

void RegisterPerson::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = false;
    }
}
void RegisterPerson::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(":/images/bg.jpg"));
}




