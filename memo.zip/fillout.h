#ifndef FILLOUT_H
#define FILLOUT_H
#include <QWidget>
#include<QToolButton>
#include<QPushButton>
#include<QMouseEvent>
#include<QDebug>
#include<QList>
#include"function.h"
#include"word.h"
#include"wordservice.h"
#include"errow.h"
#include"QPainter"
//#include"information.h"
namespace Ui {
class FillOut;
}

class FillOut : public QWidget
{
    Q_OBJECT

public:
    FillOut();
    explicit FillOut(QWidget *parent,int type,Word strword);

    ~FillOut();
    WordService m_wordservice;
    void Update(QString ci);//自定义槽函数 更新单词
    void GetWord();//在数据库获取单词
    void PointOut();//提示单词
    void bian(QString ci);//换单词
    void DeleteWord();//删除单词 回退按钮
    void IntoLexicon();//进入生词库
    void Shake();//错误时 抖动
    void paintEvent(QPaintEvent *event);
    void IsTrue();
    /**
     * @brief disorder 乱序函数
     */
    void disorder();
    QVector<QToolButton *>btns;//存储填空按钮
    QVector<QToolButton *>btns2;//存储英文字母按钮
    QString str1[24];//存储未填写状态的单词
    QString str2[24];//存放乱序单词
    QString m_str_english;//接受从数据库读取的单词 英语
    QString m_str_chinese;//接受从数据库读取的单词 汉语
    QString str3[20];//存储未填写状态的单词
    QList<QString>list;//存放乱序单词
    WordService wordservice;
    int m;//用于更新单词的变量
    Word m_word;//用于存储从数据库读取的单词
   // Word m_wordd[10];//测试
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    bool m_bDrag;
    QPoint mouseStartPoint;
    QPoint windowTopLeftPoint;
signals:
    void change(QString ci);//自定义信号

private:
    Ui::FillOut *ui;
};

#endif // FILLOUT_H
