#include "user.h"
User::User()
{
}
User::User(QString user, QString password, QString birthday, int id, QDateTime time)
{
    this->id=id;
    this->birthday=birthday;
    this->account=user;
    this->rigster_datetime=time;
    this->password=password;
}

