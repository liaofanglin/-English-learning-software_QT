#ifndef FINDWORD_H
#define FINDWORD_H

#include <QWidget>
#include"function.h"
#include<QPainter>
#include"wordservice.h"

namespace Ui {
class FindWord;
}

class FindWord : public QWidget
{
    Q_OBJECT

public:
    explicit FindWord(QWidget *parent = nullptr);
     WordService wordservice;
    ~FindWord();
    void paintEvent(QPaintEvent *event);
private slots:
    void on_btnClose_clicked();
    void on_btn_find_english_clicked();

    void on_btn_find_chinese_clicked();

private:
    Ui::FindWord *ui;
};

#endif // FINDWORD_H

