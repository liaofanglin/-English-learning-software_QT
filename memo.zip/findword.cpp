#include "findword.h"
#include "ui_findword.h"

FindWord::FindWord(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FindWord)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉边框
    connect(ui->btnMin,&QToolButton::clicked,this,&QWidget::showMinimized);
    connect(ui->btnBack,&QToolButton::clicked,this,[=](){
    Function *function=new Function(nullptr);
    function->move(this->x(),this->y());
    function->show();
    this->hide();
    });
    //ui->label_3->setStyleSheet("background-image:url(:/imagess/erge.png)");//设置背景图
    ui->btn_find_english->setStyleSheet("background-color:#32DFF2;color:white;border-radius:20px");
    ui->btn_find_chinese->setStyleSheet("background-color:#32DFF2;color:white;border-radius:20px");
}
FindWord::~FindWord()
{
    delete ui;
}
void FindWord::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(":/images/20220906160438.png"));
}
void FindWord::on_btnClose_clicked()
{
    this->close();
    //exit(0);
}
void FindWord::on_btn_find_english_clicked()
{
    Word myword=wordservice.FindEnglish(ui->linefindenglish->text());
    QString outcome=QString("%1---->%2").arg(ui->linefindenglish->text()).arg(myword.word);
    ui->texteditFindenglish->setText(outcome);
}

void FindWord::on_btn_find_chinese_clicked()
{
    Word myword=wordservice.FindChinese(ui->linefindchinese->text());
    QString outcome=QString("%1---->%2").arg(ui->linefindchinese->text()).arg(myword.translate);
    ui->texteditFindchinese->setText(outcome);
}
