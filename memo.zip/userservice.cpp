#include <QMessageBox>
#include "userservice.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>
#include<QFile>
#include<QDir>
UserService::UserService()
{

    m_dbName = "Danci.db";   // 数据库名
    m_host = "localhost";  // 主机
    m_user = "root"; // 登录用户名
    m_pwd = "123456"; // 登录密码
}

// 登录
bool UserService::login(User *objUser)
{
    connectAndOpenDb();
    QString sql = QString("SELECT id FROM sys_admin "
                         " WHERE account='%1' and password='%2'").arg(objUser->account, objUser->password);
    // 创建查询对象
    QSqlQuery query(sql);
    // 执行
    int id = 0;
    if(query.first())
        id = query.value(0).toInt();
    qDebug()<<id;
    // 关闭连接
    db.close();
    if (id > 0) {
        objUser->id = id;
        return true;
    }
    else{
        return false;
    }
}

// 账号是否存在
bool UserService::isAccountExist(QString account)
{
    connectAndOpenDb();
    QString sql = QString("SELECT COUNT(*) FROM sys_admin "
                          "WHERE account='%1'").arg(account);
    // 创建查询对象
    QSqlQuery query(sql);
    // 执行
    int id = 0;
    if(query.first())
        id = query.value(0).toInt();
    qDebug()<<id;
    // 关闭连接
    db.close();
    if (id > 0) {
        return true;
    }
    else{
        return false;
    }
}

// 注册用户
bool UserService::registerUser(User *objUser)
{
    connectAndOpenDb();
    QString sql = QString("INSERT INTO sys_admin (account, password, birthday, rigster_datetime)"
                          "VALUES ('%1','%2', '%3',' ')").arg(objUser->account, objUser->password, objUser->birthday);
    qDebug() << sql;
    QSqlQuery query;
    bool res = query.exec(sql);
    db.close();
    return res;
}

// 同时验证账号和出生日期是否存在
bool UserService::verifyAccoutAndBirthday(QString account, QString birthday)
{
    connectAndOpenDb();
    QString sql = QString("SELECT COUNT(*) FROM sys_admin "
                          "WHERE account='%1' and birthday='%2'").arg(account, birthday);
    // 创建查询对象
    QSqlQuery query(sql);
    // 执行
    int id = 0;
    if(query.first())
        id = query.value(0).toInt();
    qDebug()<<id;
    // 关闭连接
    db.close();
    if (id > 0) {
        return true;
    }
    else{
        return false;
    }
}

// 编辑密码
bool UserService::modifyPassword(User *objUser)
{
    connectAndOpenDb();
    QString sql = QString("UPDATE sys_admin SET password='%1' "
                          "WHERE account='%2' and birthday='%3'").arg(objUser->password, objUser->account, objUser->birthday);
    qDebug() << sql;
    QSqlQuery query;
    bool res = query.exec(sql);
    db.close();
    return res;
}


// 创建数据库连接对象并打开
void UserService::connectAndOpenDb()
{
    // 创建数据库连接对象
    if(QSqlDatabase::contains("qt_sql_default_connection"))
    {
        db=QSqlDatabase::database("qt_sql_default_connection");
    }
    else {
        db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName(m_dbName);
        db.setUserName(m_user);
        db.setPassword(m_pwd);
    }
    if(!db.open())
    {
         qDebug()<<"error to open"<<db.lastError();
    }
    else {

    }
}

QString UserService::AddPassword()
{
    QDir dir;
    QString str=dir.currentPath()+QString("/sqlpwd.txt");
    QFile passFile(str);
    passFile.open(QIODevice::ReadOnly | QIODevice::Text);
    QTextStream qts(&passFile);
    QString m_password;
    qts>>m_password;
    return  m_password;
}

