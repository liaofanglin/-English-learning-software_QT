#include "word.h"

Word::Word()
{

}
