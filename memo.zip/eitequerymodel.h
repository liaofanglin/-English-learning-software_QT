#ifndef EITEQUERYMODEL_H
#define EITEQUERYMODEL_H
#include<QSqlQueryModel>

class eiteQuerymodel: public QSqlQueryModel
{
public:
    eiteQuerymodel();
    QVariant data(const QModelIndex &index,int role=Qt::DisplayRole)const;
    //重写接口的虚函数
    bool setData(const QModelIndex&index,const QVariant&value,int role);
    Qt::ItemFlags flags(const QModelIndex &index)const;

private:
    //自定义接口
    //更新数据
    void refresh();

    //根据需求来定义修改表中的内容的接口
    bool setName(int useId,const QString &name);
    bool setAge(int useId,const int &age);
    bool setaddress(int useId,const QString &address);
    bool setsalary(int useId,const int &salary);
};

#endif // EITEQUERYMODEL_H
