#include "type.h"

type::type()
{

}
