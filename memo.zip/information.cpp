#include"information.h"

User *m_user=new User();

