#include "mynote.h"
#include "ui_mynote.h"

mynote::mynote(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::mynote)
{
    ui->setupUi(this);
    this->setWindowTitle("记事本");//修改窗口标题
    this->resize(800,500);//设置窗口大小

    //将动作按钮的提示添加到状态栏
    //文件菜单
    ui->actionNew->setStatusTip("新建文本文件");
    ui->actionOpen->setStatusTip("打开文本文件");
    ui->actionSave->setStatusTip("保存文本文件");
    ui->actionSaveAs->setStatusTip("另存文本文件");
    //ui->actionPageSetup_2->setStatusTip("页面设置");
   // ui->actionPrint->setStatusTip("打印");
    ui->actionExit->setStatusTip("直接退出记事本");
    //编辑菜单
    ui->actionRepeal->setStatusTip("撤销本次操作,返回上一次操作");
    ui->actionNoRepal->setStatusTip("取消撤销操作");
    ui->actionCut->setStatusTip("剪切文本内容");
    ui->actionCopy->setStatusTip("复制文本内容");
    ui->actionPaste->setStatusTip("粘贴文本内容");
    ui->actionDateTime->setStatusTip("将日期时间显示到文本输入框");
    //格式菜单
    ui->actionFont->setStatusTip("设置字体");
    ui->actionColor->setStatusTip("设置字体颜色");
    //帮助菜单
    ui->actionInRegardTo->setStatusTip("关于记事本");
    ui->actionShowHelp->setStatusTip("跳转至记事本帮助网页");


    //信号和槽的关联
    //triggered()------>点触函数
    //文件菜单
    connect(ui->actionNew,SIGNAL(triggered(bool)),this,SLOT(newfile()));//点击新建按钮,新建窗口
    connect(ui->actionOpen,SIGNAL(triggered(bool)),this,SLOT(openfile()));//点击打开按钮,选择文件,并打开
    connect(ui->actionSave,SIGNAL(triggered(bool)),this,SLOT(savefile()));//点击保存按钮,将写入内容保存到文件
    connect(ui->actionSaveAs,SIGNAL(triggered(bool)),this,SLOT(saveAsfile()));//点击另存为按钮,将写入内容另存为到文件
    //connect(ui->actionPageSetup_2,SIGNAL(triggered(bool)),this,SLOT(pageSetup()));//点击页面设置按钮,打开页面设置对话框
    //connect(ui->actionPrint,SIGNAL(triggered(bool)),this,SLOT(printfile()));//点击打印按钮,打开打印对话框
    connect(ui->actionExit,SIGNAL(triggered(bool)),this,SLOT(closenotepad()));//直接退出记事本
    //编辑菜单
    connect(ui->actionRepeal,SIGNAL(triggered(bool)),this,SLOT(_repeal()));//点击撤销按钮,执行撤销操作
    connect(ui->actionNoRepal,SIGNAL(triggered(bool)),this,SLOT(_norepeal()));//点击反撤销按钮,执行取消撤销操作
    connect(ui->actionCut,SIGNAL(triggered(bool)),this,SLOT(_cut()));//点击剪切按钮,执行剪切操作
    connect(ui->actionCopy,SIGNAL(triggered(bool)),this,SLOT(_copy()));//点击复制按钮,执行复制操作
    connect(ui->actionPaste,SIGNAL(triggered(bool)),this,SLOT(_paste()));//点击粘贴按钮,执行粘贴操作
    connect(ui->actionDateTime,SIGNAL(triggered(bool)),this,SLOT(_dateTime()));//点击日期时间按钮,显示日期时间到文本输入框
    //格式菜单
    connect(ui->actionFont,SIGNAL(triggered(bool)),this,SLOT(_font()));//点击设置字体按钮,对文本输入框选中的内容执行字体设置操作
    connect(ui->actionColor,SIGNAL(triggered(bool)),this,SLOT(_color()));//点击设置字体颜色按钮,对文本输入框选中的内容执行字体颜色设置操作
    //帮助菜单
    connect(ui->actionShowHelp,SIGNAL(triggered(bool)),this,SLOT(showHelp()));//点击查看帮助按钮,弹出记事本的帮助网页
    connect(ui->actionInRegardTo,SIGNAL(triggered(bool)),this,SLOT(inRegardTo()));//点击关于记事本按钮,弹出记事本相关信息的关于

}

mynote::~mynote()
{
    delete ui;

}
//文件菜单
void mynote::newfile()
{
    this->setWindowTitle("新文本");//设置新建窗体的标题
    ui->textEdit->clear();//清空textEdit中的内容
}

QString mynote::openfile()//打开文件
{
    //调用打开文件对话框
    QString filter="Image(*.png;*.jpg);;text files(*.txt);;all files(*.*)";
    QString defFileter="text files(*.txt)";
    QString filename=QFileDialog::getOpenFileName(this,"打开文件/目录",QDir::currentPath(),filter,&defFileter);
    if(!filename.isEmpty())//文件名不为空
    {
            //打开文件
            QFile file(filename);
            bool ret=file.open(QIODevice::ReadOnly);//只读方式打开
            if(ret==true)
            {
                //QTextStream--->操作纯文本文件的类,流的方式读写文件
                QTextStream _write(&file);//创建写出流
                QString str=_write.readAll();//读取数据
                ui->textEdit->setText(str);//将字符串显示在文本输入框
                //设置打开文件的标题
                QFileInfo info(filename);
                QString str1=info.fileName();
                this->setWindowTitle(str1);
                //返回文件名,为文件保存提供入口
                _filename=str1;
                return _filename;
                //关闭文件
                file.close();
             }
    }
}

void mynote::savefile()//保存文件
{
    if(_filename.isEmpty())//如果文件名为空,则执行另存为操作
    {
        saveAsfile();
    }
    else
    {
        //打开文件
        QFile file(_filename);
        bool ret=file.open(QIODevice::WriteOnly);//只写方式打开
        if(ret==true)
        {
            //QTextStream--->操作纯文本文件的类,流的方式读写文件
            QTextStream _write(&file);//创建写入流
            // toPlainText()---->将textEdit控件上的全部文字内容输出为一个字符串
            _write<<ui->textEdit->toPlainText();//写入数据
            //调用信息对话框,提示文件保存成功
            QMessageBox::information(this,"提示","文件保存成功");
            //关闭文件
            file.close();
         }
    }
}

void mynote::saveAsfile()//另存为
{
       //调用保存文件对话框
       QString filter="Image(*.png;*.jpg);;text files(*.txt);;all files(*.*)";
       QString defFileter="text files(*.txt)";
       QString filename=QFileDialog::getSaveFileName(this,"保存文件/目录",QDir::currentPath(),filter,&defFileter);
       if(!filename.isEmpty())//文件名不为空
       {
            //打开文件
            QFile file1(filename);
            bool ret1=file1.open(QIODevice::WriteOnly);//只写方式打开
            if(ret1==true)
            {
                //QTextStream--->操作纯文本文件的类,流的方式读写文件
                QTextStream _write1(&file1);//创建写入流
                // toPlainText()---->将textEdit控件上的全部文字内容输出为字符串
                _write1<<ui->textEdit->toPlainText();//写入数据
                //关闭文件
                file1.close();
             }
       }
}

//void mynote::pageSetup()//页面设置
//{
//    QPrinter printer;//定义一个打印机对象
//    QPageSetupDialog pageSetup(&printer,this);//创建页面设置对话框
//    if(pageSetup.exec()==QDialog::Accepted)//如果在对话框中按下页面按钮,打开页面设置对话框
//    {
//        printer.setOrientation(QPrinter::Landscape);//设置页面对话框里的方向为横向
//    }
//    else
//    {
//        printer.setOrientation(QPrinter::Portrait);//设置页面对话框里的方向为纵向   str.data()
//    }
//}

//void mynote::printfile()//打印
//{
//    QPrinter printer;//定义一个打印机对象
//    QPrintDialog log(&printer,this);//创建打印对话框
//    if(ui->textEdit->textCursor().hasSelection())//如果文本输入框有选中区域,则打印选中区域
//    {
//       log.addEnabledOption(QAbstractPrintDialog::PrintSelection);
//    }
//    if(log.exec()==QDialog::Accepted)//如果在对话框中按下打印按钮,打开打印对话框
//    {
//         ui->textEdit->print(&printer);//执行打印操作
//    }
//}

void mynote::closenotepad()//直接退出
{
    this->close();
}


int mynote::closeMessageBox(QString Title, QString text)//自定义的关闭对话框,参数是对话框的标题、正文内容
{
    QMessageBox cmsgBox;//定义一个消息对话框对象
    cmsgBox.setWindowTitle(Title);//设置对话框的标题
    cmsgBox.setText(text);//设置对话框的正文内容
    cmsgBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);//设置按钮的标准值
    cmsgBox.setButtonText(QMessageBox::Save,"保存");//设置按钮标题为保存
    cmsgBox.setButtonText(QMessageBox::Discard,"不保存");//设置按钮标题为保存
    cmsgBox.setButtonText(QMessageBox::Cancel,"取消");//设置按钮标题为保存
    return cmsgBox.exec();//返回用户选择的按钮
}


void mynote::closeEvent(QCloseEvent *event)//关闭事件
{
    //document()->isModified()----->获取文档内容是否有改动(true 表示文档内容已改动,false 表示文档内容还未改动)
    bool isModified = ui->textEdit->document()->isModified();//当前文档已经改变----->isModified=true
    if(isModified)
    {
       QString text("是否将更改保存到");//text(关闭时,消息对话框的正文内容)
       //用三目运算符判断文件名是否为空
       text += _filename.isEmpty()?("无标题？"):_filename;//isEmpty()----->为空(true),则文件名为无标题,否则为所打开的文件名
       switch (closeMessageBox("记事本",text))//调用自定义的关闭对话框函数,返回值为用户选择的按钮
       {
          case QMessageBox::Save://保存
          savefile();//调用保存文件函数
          break;
          case QMessageBox::Discard://点击不保存,直接退出
          break;
          case QMessageBox::Cancel://取消
          event->ignore();//忽略退出信号
          break;
          default:
          break;
       }
   }
}

//编辑菜单
void mynote::_repeal()//撤销
{
    _undoStack->createUndoAction(this);//调用撤销命令操作当前窗口
}

void mynote::_norepeal()//取消撤销
{
    _noUndoStack->createRedoAction(this);//调用取消撤销命令操作当前窗口
}

void mynote::_cut()//剪切
{
    //QApplication::clipboard()函数---->访问系统剪切板,返回一个剪切板对象指针
    QClipboard *board = QApplication::clipboard();
    board->setText(ui->textEdit->toPlainText());//通过setText()函数,将数据存放到系统剪切板, toPlainText()---->将textEdit控件上的全部文字内容输出为字符串
}

void mynote::_copy()//复制
{
    ui->textEdit->copy();//调用文本输入框(textEdit)中的复制命令操作文本输入框中的内容----->也是将数据存放到系统剪切板
}

void mynote::_paste()//粘贴
{
    QClipboard *board = QApplication::clipboard();//访问系统剪切板,返回一个剪切板对象指针
    board->text();//通过text()函数,将剪切或者复制的数据放到文本输入框
}

void mynote::_dateTime()//显示日期时间到文本输入框
{
    //通过日期时间类(QDateTime)中的currentDateTime()函数获取系统日期时间
    QDateTime dt=QDateTime::currentDateTime();
    //调用日期时间类(QDateTime)中的toString()函数将系统日期时间转换成字符串
    QString str=dt.toString("yyyy-MM-dd hh:mm:ss");
    //通过insertPlainText()函数将字符串显示到文本内容的最后面,且不换行
    ui->textEdit->insertPlainText(str);
}

//格式菜单
void mynote::_font()//设置字体
{
    //定义一个保存点击确定按钮值
    bool ok;
    //获取textEdit中的字体默认样式
    QFont f=ui->textEdit->font();
    //通过getFont(),得到一个字体对话框,返回值是已经选择好的字体样式
    QFont font=QFontDialog::getFont(&ok,f,Q_NULLPTR,"设置字体");
    //设置文本输入框中内容的字体------>setFont()
    if(ok)
    {
        ui->textEdit->setFont(font);
    }
    else
    {
        //设置字体失败,弹出失败提示对话框
         QMessageBox::information(this,"提示","字体设置失败");
    }
}

void mynote::_color()//设置字体颜色
{
    //通过getColor(),得到一个颜色对话框,返回值是用户选中的颜色值
    //QColorDialog::DontUseNativeDialog-------->使用Qt提供的标准颜色库
    QColor color=QColorDialog::getColor(Qt::red,Q_NULLPTR,"设置字体颜色",QColorDialog::DontUseNativeDialog);
    //设置文本输入框选中的文本值的字体颜色------>setTextColor()
    ui->textEdit->setTextColor(color);
}

//帮助菜单
void mynote::showHelp()//记事本的帮助网页
{
    //定义一个可以打开本地浏览器的类对象
    QDesktopServices desktopServices;
    //定义一个网址类对象,输入网址
    QUrl url(QString("https://cn.bing.com/search?q=%E8%8E%B7%E5%8F%96%E6%9C%89%E5%85%B3+windows+10+%E4%B8%AD%E7%9A%84%E8%AE%B0%E4%BA%8B%E6%9C%AC%E7%9A%84%E5%B8%AE%E5%8A%A9&filters=guid:%224466414-zh-hans-dia%22%20lang:%22zh-hans%22&form=T00032&ocid=HelpPane-BingIA"));
    //打开该网址
    desktopServices.openUrl(url);
}

void mynote::inRegardTo()//记事本相关信息的关于对话框
{
    //直接调用自定义的关于对话框
    QMessageBox::about(this,"关于“记事本”","该记事本项目分为文件模块，编辑模块，格式模块，帮助模块,工具栏模块");
}

