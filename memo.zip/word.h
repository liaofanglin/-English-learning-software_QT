#ifndef WORD_H
#define WORD_H

#include<QString>
class Word
{
public:
    Word();
    Word(QString english,QString chinese,int id);//初始化单词
    QString word;//英文
    QString translate;//汉语
    int id;//id号

};

#endif // WORD_H
