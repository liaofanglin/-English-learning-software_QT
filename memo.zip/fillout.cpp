#include "fillout.h"
#include "ui_fillout.h"
#include<QVBoxLayout>
#include<QGraphicsDropShadowEffect>
FillOut::FillOut()
{
    ui->setupUi(this);
}
FillOut::FillOut(QWidget *parent,int type,Word strword) :
    QWidget(parent),
    ui(new Ui::FillOut)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉边框
    //Errow *error=new Errow(this,"填写错误");
    //ui->label->setStyleSheet("background-image:url(:/images/20220906152220.png)");//设置背景图
    m_word.id=-1;
    m=1;//记录位置 从第一个空开始填写
    list<<"a"<<"b"<<"c"<<"d"<<"e"<<"f"<<"g"<<"h"<<"i"<<"f"<<"j"<<"k"<<"l"<<"m"
       <<"n"<<"o"<<"p"<<"q"<<"r"<<"s"<<"t"<<"u"<<"v"<<"w"<<"x"<<"y"<<"z";
    //如果是从功能页 进入 那么type=1则 进行从数据库随机获取单词
    if(type==1)
    {
        do
        {
          this->m_word=this->m_wordservice.getRandomWord(m_word.id);
           m_str_english=this->m_word.word;
          m_str_chinese=this->m_word.translate;
        }while(m_str_english.length()>12);
         this->GetWord();
    }
    //如果type=0 那么就获取生词库的单词 并将其显示
    else if (type==0) {
        m_str_english=strword.word;
        m_str_chinese=strword.translate;
         this->GetWord();
    }
       //关联提示按钮
       connect(ui->btnShow,&QPushButton::clicked,this,&FillOut::PointOut);
       //关联跳过按钮  释放原来按钮 创建新的按钮
       connect(ui->btnPass,&QPushButton::clicked,[=](){
           //点击pass按钮 销毁原按钮 创建新按钮
       for(QVector<QToolButton *>::iterator it=btns.begin();it!=btns.end();it++)
       {
           delete (*it);
       }
       for(QVector<QToolButton *>::iterator it=btns2.begin();it!=btns2.end();it++)
       {
           delete (*it);
       }
       btns.clear();
       btns2.clear();
       do
       {
         this->m_word=this->m_wordservice.getRandomWord(m_word.id);
          m_str_english=this->m_word.word;
         m_str_chinese=this->m_word.translate;
       }while(m_str_english.length()>12);

       GetWord();
   });
       //更新单词
      connect(this,&FillOut::change,this,&FillOut::Update);
      //回删
      connect(ui->btnDelete,&QToolButton::clicked,this,&FillOut::DeleteWord);

      connect(ui->btnClose,&QPushButton::clicked,this,[=](){
          this->close();
      });

      //添加词库
      connect(ui->btnAddWord,&QToolButton::clicked,[=](){

          this->wordservice.addWord(this->m_word.id,m_user->id);
          Errow *errow=new Errow(this,"添加成功");
          errow->show();
          emit ui->btnShow->clicked();
      });

      //显示词库
      connect(ui->btnShowLexicon,&QToolButton::clicked,[=](){
          UnfamilyWord *unfamily=new UnfamilyWord(nullptr);
          unfamily->move(this->x(),this->y());
          unfamily->show();
          this->hide();
      });
      //最小化
      connect(ui->btnMin,&QToolButton::clicked,this,&QWidget::showMinimized);
      connect(ui->btnBack,&QToolButton::clicked,this,[=](){
         Function *function=new Function(nullptr);
         function->move(this->x(),this->y());
         function->show();
          this->hide();
      });
      for(int i=0;i<5;i++)
      {
          QGraphicsDropShadowEffect *shadow_effect = new QGraphicsDropShadowEffect(this);
          shadow_effect->setOffset(3, 3);
          shadow_effect->setColor(QColor(43,43,43,50));
          shadow_effect->setBlurRadius(8);
          if(i==0)
          {
             ui->btnAddWord->setGraphicsEffect(shadow_effect);
          }
          else if (i==1) {
               ui->btnPass->setGraphicsEffect(shadow_effect);
          }
          else if (i==2) {
               ui->btnDelete->setGraphicsEffect(shadow_effect);
          }
          else if (i==3) {
              ui->btnShow->setGraphicsEffect(shadow_effect);

          }
          else if (i==4) {
                ui->btnShowLexicon->setGraphicsEffect(shadow_effect);
          }
      }
}
FillOut::~FillOut()
{
    delete ui;
}
void FillOut::GetWord()
{
    m=1;
    //将汉语显示在屏幕上
    ui->labelChinese->setStyleSheet(QString("font-family:PingFang SC;color:white;font-size:32px"));
    ui->labelChinese->setText(m_str_chinese);
    for(int i=0;i<m_str_english.length();i++)
    {
        str1[i]=m_str_english[i];
        str2[i]=m_str_english[i];
        //首字母和尾字母存储起来 其他位置变为_
        if(i==0)
        {
            str3[i]=m_str_english[0];

        }
        else if (i==m_str_english.length()-1) {
            str3[i]=m_str_english[m_str_english.length()-1];
        }
        else {
            str3[i]="_";
        }
    }

    for(int i=0;i<m_str_english.length();i++)
    {
        QToolButton *btn=new QToolButton(this);
        btn->setAutoRaise(true);
        btn->setStyleSheet("font-size:35px;font-weight:bold;color:white;");
        btn->setText(str3[i]);
        btn->setFont(QFont("苹方字体"));
        btn->setFixedSize(QSize(38,40));
        btn->move((this->width()-(m_str_english.length()*38))/2+38*i,305);
        btn->show();
        btns.push_back(btn);
    }

    for(int i=0;i<24-m_str_english.length();i++)
    {
        str2[m_str_english.length()+i]=list[i];
    }
    //对里面的内容乱序
    disorder();
    for(int i=0;i<24;i++)
     {
         QToolButton *btn=new QToolButton(this);
         btn->setStyleSheet("width:44px;height:44px;font-size:36px;border-radius:2px;color:#636363;border: 1px solid #929292;;background-color:white;");
         btn->setFont(QFont("苹方字体"));

         //对按钮设置阴影
         QGraphicsDropShadowEffect *shadow_effect = new QGraphicsDropShadowEffect(this);
         shadow_effect->setOffset(3, 3);
         shadow_effect->setColor(QColor(43,43,43,50));
         shadow_effect->setBlurRadius(8);
         btn->setGraphicsEffect(shadow_effect);
         //将按钮移动进行布局
         if(i<6)
         {
            btn->move(40+64*i,545);
         }
         else if (i>=6&&i<12) {
             btn->move(40+64*(i-6),609);
         }
         else if (i>=12&&i<18) {
             btn->move(40+64*(i-12),673);
         }
         else {
             btn->move(40+64*(i-18),737);
         }
         btn->setText(str2[i]);
         btn->show();
         //添加按键的音频
         connect(btn,&QToolButton::clicked,this,[=]()mutable{
                emit change(btn->text());
         });
         btns2.push_back(btn);
     }
}

void FillOut::PointOut()
{
    int i=0;
    for(QVector<QToolButton *>::iterator it=btns.begin();it!=btns.end()-1;it++,i++)
    {
        (*it)->setText(str1[i]);
    }
}
void FillOut::Update(QString ci)
{
    //用户填写单词时  对该项目的单词进行更新
    if(m!=this->m_str_english.length()-1)
    {
         str3[m]=ci;
    }
    int i=0;

    for(QVector<QToolButton *>::iterator it=btns.begin();it!=btns.end()-1;it++,i++)
    {

        (*it)->setText(str3[i]);
      //  qDebug()<<i;
    }
    if(m!=this->m_str_english.length()-1)
    {
            m++;
    }
    IsTrue();
}
void FillOut::DeleteWord()
{
    if(m>1)
    {
        m--;

        str3[m]="_";
        int i=0;
        for(QVector<QToolButton *>::iterator it=btns.begin();it!=btns.end()-1;it++,i++)
        {
          (*it)->setText(str3[i]);
            //  qDebug()<<i;
        }
    }
}

void FillOut::Shake()
{
    //窗口抖动的动画化
    QPropertyAnimation *pAnimation = new QPropertyAnimation(this, "pos");
    pAnimation->setDuration(500);
    pAnimation->setLoopCount(2);
    pAnimation->setKeyValueAt(0, QPoint(this->x() - 3, this->y()));
    pAnimation->setKeyValueAt(0.1, QPoint(this->x() + 6, this->y() ));
    pAnimation->setKeyValueAt(0.2, QPoint(this->x() - 6, this->y() ));
    pAnimation->setKeyValueAt(0.3, QPoint(this->x() + 6, this->y() ));
    pAnimation->setKeyValueAt(0.4, QPoint(this->x() - 3, this->y()));
    pAnimation->start(QAbstractAnimation::DeleteWhenStopped);
}

void FillOut::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(":/imagess/bg.jpg"));
    painter.drawPixmap(0,525,this->width(),355,QPixmap(":/imagess/bg222.png"));
}

void FillOut::IsTrue()
{
    //判断单词是否填写正确
    QString istrue;
    if(m==this->m_str_english.length()-1)
    {

        for(int i=0;i<m_str_english.length();i++)
        {
            istrue+=this->str3[i];
        }
        if(istrue==m_str_english)
        {
            //单词填写正确 激活跳过信号
            emit ui->btnPass->clicked();
        }
        else {
            Errow *error=new Errow(this,"拼写错误");
            error->show();
            Shake();
        }
    }
}
void FillOut::disorder()
{
   srand((unsigned)time(0));

   //进行24次字母交换 达到乱序
   for(int i=0;i<24;i++)
    {
       //随机产生下标 对数组里字母进行交换
        int a1=rand()%24;
        int a2=rand()%24;
        QString temp=str2[a1];
        str2[a1]=str2[a2];
        str2[a2]=temp;
    }
   /*
    * 测试  乱序是否成功
   */
    /*for(int i=0;i<24;i++)
    {
        qDebug()<<list[i];
    }*/
}

void FillOut::mousePressEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = true;
        //获得鼠标的初始位置
        mouseStartPoint = event->globalPos();
        //mouseStartPoint = event->pos();
        //获得窗口的初始位置
        windowTopLeftPoint = this->frameGeometry().topLeft();
    }
}

void FillOut::mouseMoveEvent(QMouseEvent *event)
{
    if(m_bDrag)
    {
        //获得鼠标移动的距离
        QPoint distance = event->globalPos() - mouseStartPoint;
        //QPoint distance = event->pos() - mouseStartPoint;
        //改变窗口的位置
        this->move(windowTopLeftPoint + distance);
    }
}

void FillOut::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton)
    {
        m_bDrag = false;
    }
}



