#ifndef ERROW_H
#define ERROW_H

#include <QWidget>
#include<QPropertyAnimation>
#include<QTimer>
namespace Ui {
class Errow;
}
class Errow : public QWidget
{
    Q_OBJECT

public:
    Errow();
    //参数1：父类 参数2：错误信息
    explicit Errow(QWidget *parent,QString m_error);
    ~Errow();

private:
    Ui::Errow *ui;
};

#endif // ERROW_H
