#ifndef WORKERLIST_H
#define WORKERLIST_H

#include <QWidget>

namespace Ui {
class WorkerList;
}

/**
 * @brief 开发人员名单类
 */
class WorkerList : public QWidget
{
    Q_OBJECT

public:
    explicit WorkerList(QWidget *parent = nullptr);
    ~WorkerList();

private:
    Ui::WorkerList *ui;
};

#endif // WORKERLIST_H

