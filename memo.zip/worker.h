#ifndef WORKER_H
#define WORKER_H

#include <QWidget>

namespace Ui {
class Worker;
}

/**
 * @brief 开发人员类
 */
class Worker : public QWidget
{
    Q_OBJECT

public:
    explicit Worker(QWidget *parent = nullptr);
    ~Worker();

private:
    Ui::Worker *ui;
};

#endif // WORKER_H

